-- MySQL dump 10.13  Distrib 5.1.32, for apple-darwin9.5.0 (i386)
--
-- Host: localhost    Database: 1well_development
-- ------------------------------------------------------
-- Server version	5.1.32

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `1well_development`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `1well_development` /*!40100 DEFAULT CHARACTER SET latin1 */;

USE `1well_development`;

--
-- Table structure for table `basic_user_details`
--

DROP TABLE IF EXISTS `basic_user_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `basic_user_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `zip` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `skype_username` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `basic_user_details`
--

LOCK TABLES `basic_user_details` WRITE;
/*!40000 ALTER TABLE `basic_user_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `basic_user_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_assets`
--

DROP TABLE IF EXISTS `blog_assets`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `blog_assets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `blog_post_id` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `content_type` varchar(255) DEFAULT NULL,
  `filename` varchar(255) DEFAULT NULL,
  `thumbnail` varchar(255) DEFAULT NULL,
  `size` int(11) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `blog_assets`
--

LOCK TABLES `blog_assets` WRITE;
/*!40000 ALTER TABLE `blog_assets` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_assets` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_categories`
--

DROP TABLE IF EXISTS `blog_categories`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `blog_categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `blog_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_blog_categories_on_blog_id` (`blog_id`),
  KEY `index_blog_categories_on_parent_id` (`parent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `blog_categories`
--

LOCK TABLES `blog_categories` WRITE;
/*!40000 ALTER TABLE `blog_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_comments`
--

DROP TABLE IF EXISTS `blog_comments`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `blog_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `blog_post_id` int(11) DEFAULT NULL,
  `comment` text,
  `approved` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_blog_comments_on_blog_post_id` (`blog_post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `blog_comments`
--

LOCK TABLES `blog_comments` WRITE;
/*!40000 ALTER TABLE `blog_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_comments` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_posts`
--

DROP TABLE IF EXISTS `blog_posts`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `blog_posts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `body` text,
  `tag_string` varchar(255) DEFAULT NULL,
  `posted_by_id` int(11) DEFAULT NULL,
  `is_complete` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `url_identifier` varchar(255) DEFAULT NULL,
  `comments_closed` tinyint(1) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `blog_id` int(11) DEFAULT '1',
  `fck_created` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_blog_posts_on_category_id` (`category_id`),
  KEY `index_blog_posts_on_url_identifier` (`url_identifier`),
  KEY `index_blog_posts_on_blog_id` (`blog_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `blog_posts`
--

LOCK TABLES `blog_posts` WRITE;
/*!40000 ALTER TABLE `blog_posts` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_posts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_tags`
--

DROP TABLE IF EXISTS `blog_tags`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `blog_tags` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `blog_post_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_blog_tags_on_blog_post_id` (`blog_post_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `blog_tags`
--

LOCK TABLES `blog_tags` WRITE;
/*!40000 ALTER TABLE `blog_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blogs`
--

DROP TABLE IF EXISTS `blogs`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `blogs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `url_identifier` varchar(255) DEFAULT NULL,
  `stylesheet` varchar(255) DEFAULT NULL,
  `feedburner_url` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `index_blogs_on_url_identifier` (`url_identifier`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `blogs`
--

LOCK TABLES `blogs` WRITE;
/*!40000 ALTER TABLE `blogs` DISABLE KEYS */;
INSERT INTO `blogs` VALUES (1,'My Bloggity Blog','No, this blog doesn\'t have a subtitle.  What\'s it to ya?','main',NULL,NULL,'2009-09-13 16:25:28','2009-09-13 16:25:28',NULL);
/*!40000 ALTER TABLE `blogs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_member_audios`
--

DROP TABLE IF EXISTS `community_member_audios`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `community_member_audios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `community_member_profile_id` int(11) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `audio_file_name` varchar(255) DEFAULT NULL,
  `audio_content_type` varchar(255) DEFAULT NULL,
  `audio_file_size` varchar(255) DEFAULT NULL,
  `audio_updated_at` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `project_status_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `community_member_audios`
--

LOCK TABLES `community_member_audios` WRITE;
/*!40000 ALTER TABLE `community_member_audios` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_member_audios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_member_messages`
--

DROP TABLE IF EXISTS `community_member_messages`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `community_member_messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `community_member_profile_id` int(11) DEFAULT NULL,
  `content` text,
  `related_project_stage` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `community_member_messages`
--

LOCK TABLES `community_member_messages` WRITE;
/*!40000 ALTER TABLE `community_member_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_member_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_member_pictures`
--

DROP TABLE IF EXISTS `community_member_pictures`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `community_member_pictures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `community_member_profile_id` int(11) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `picture_file_name` varchar(255) DEFAULT NULL,
  `picture_content_type` varchar(255) DEFAULT NULL,
  `picture_file_size` varchar(255) DEFAULT NULL,
  `picture_updated_at` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `project_status_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `community_member_pictures`
--

LOCK TABLES `community_member_pictures` WRITE;
/*!40000 ALTER TABLE `community_member_pictures` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_member_pictures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_member_profiles`
--

DROP TABLE IF EXISTS `community_member_profiles`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `community_member_profiles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `biography` text,
  `profile_picture_file_name` varchar(255) DEFAULT NULL,
  `profile_picture_content_type` varchar(255) DEFAULT NULL,
  `profile_picture_file_size` varchar(255) DEFAULT NULL,
  `profile_picture_updated_at` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `community_member_profiles`
--

LOCK TABLES `community_member_profiles` WRITE;
/*!40000 ALTER TABLE `community_member_profiles` DISABLE KEYS */;
INSERT INTO `community_member_profiles` VALUES (1,31,'Arjun Arvindhbhai Parmar','Arjun Arvindhbhai Parmar is a class 9 student from Chikhodra village. He says that SEWA used to bear the expenses of his education which they have stopped now. “My mother is an agricultural laborer and she works on the field. She earns Rs 20 a day from this activity. With this amount she cannot meet our household expenses, therefore, it is impossible for her to bear the expenses of our education. At present, in addition to working on the field, she also works at a tobacco factory. She earns a monthly income of Rs. 1000 from these two jobs. I tell my mother that she should send my younger brother to a school and I will help her in earning money so that we can send my younger brother to school. As a result I have left my studies.”',NULL,NULL,NULL,NULL,'2009-08-25 15:27:24','2009-08-25 15:27:24');
INSERT INTO `community_member_profiles` VALUES (2,11,'Chandabenben','Chandabenben is from Sonalnagar village. Her house is two thatched roofed structures – a living area and a kitchen – that she shares with four generations of her family – her mother, herself, her daughter and her granddaughter. For cooking, she burns wood her family collects every day. Her daughter spends a few hours traveling up to 8 kilometers to collect 10-20 kilos of wood, which she carries home. If there is not sufficient wood, Chandabenben makes patties from cow dung to burn as fuel. The biogas plant will alleviate her daughter’s need to collect wood, allowing her to work and earn more income for the family. This income will be used to pay for their children’s education, by insurance, and save for the future.\r\n\r\nChandabenben shares that, “before I became a part of SEWA, I thought my work was collecting wood and making cow patties. But that takes away from my ability to earn an income and take care of my family. I need to reduce unproductive activities and focus my farming that produces food for my family and in good years, brings in additional income.”',NULL,NULL,NULL,NULL,'2009-08-25 18:49:28','2009-08-25 18:49:51');
INSERT INTO `community_member_profiles` VALUES (3,11,'Lalaben','Lalaben, mother of four, is excited about the possibility of installing a biogas unit in her home because, “it will allow me to pursue my embroidery and sewing. Not collect wood means I can produce more embroidery that I can sell.” Kankuben and Kuwarben see the same opportunity.',NULL,NULL,NULL,NULL,'2009-08-25 18:50:08','2009-08-25 18:50:08');
/*!40000 ALTER TABLE `community_member_profiles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `community_member_videos`
--

DROP TABLE IF EXISTS `community_member_videos`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `community_member_videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `community_member_profile_id` int(11) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `video_file_name` varchar(255) DEFAULT NULL,
  `video_content_type` varchar(255) DEFAULT NULL,
  `video_file_size` varchar(255) DEFAULT NULL,
  `video_updated_at` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `project_status_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `community_member_videos`
--

LOCK TABLES `community_member_videos` WRITE;
/*!40000 ALTER TABLE `community_member_videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `community_member_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `countries`
--

DROP TABLE IF EXISTS `countries`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `countries`
--

LOCK TABLES `countries` WRITE;
/*!40000 ALTER TABLE `countries` DISABLE KEYS */;
INSERT INTO `countries` VALUES (1,'Peru','2009-08-09 07:01:08','2009-08-09 07:01:08');
INSERT INTO `countries` VALUES (2,'India','2009-08-09 07:01:20','2009-08-09 07:01:20');
/*!40000 ALTER TABLE `countries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency_types`
--

DROP TABLE IF EXISTS `currency_types`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `currency_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `currency_code` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=178 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `currency_types`
--

LOCK TABLES `currency_types` WRITE;
/*!40000 ALTER TABLE `currency_types` DISABLE KEYS */;
INSERT INTO `currency_types` VALUES (1,'AFN','2009-08-09 06:34:14','2009-08-09 06:34:14');
INSERT INTO `currency_types` VALUES (2,'ALL','2009-08-09 06:34:27','2009-08-09 06:34:27');
INSERT INTO `currency_types` VALUES (4,'USD','2009-08-09 06:34:46','2009-08-09 06:34:46');
INSERT INTO `currency_types` VALUES (5,'EUR','2009-08-09 06:34:57','2009-08-09 06:34:57');
INSERT INTO `currency_types` VALUES (6,'AOA','2009-08-09 06:35:07','2009-08-09 06:35:07');
INSERT INTO `currency_types` VALUES (8,'ARS','2009-08-09 06:35:23','2009-08-09 06:35:23');
INSERT INTO `currency_types` VALUES (9,'AMD','2009-08-09 06:35:33','2009-08-09 06:35:33');
INSERT INTO `currency_types` VALUES (10,'AWG','2009-08-09 06:35:45','2009-08-09 06:35:45');
INSERT INTO `currency_types` VALUES (11,'AUD','2009-08-09 06:35:52','2009-08-09 06:35:52');
INSERT INTO `currency_types` VALUES (12,'AZN','2009-08-09 06:37:31','2009-08-09 06:37:31');
INSERT INTO `currency_types` VALUES (13,'BSD','2009-08-09 06:37:42','2009-08-09 06:37:42');
INSERT INTO `currency_types` VALUES (14,'BHD','2009-08-09 06:37:51','2009-08-09 06:37:51');
INSERT INTO `currency_types` VALUES (15,'BDT','2009-08-09 06:38:03','2009-08-09 06:38:03');
INSERT INTO `currency_types` VALUES (16,'BBD','2009-08-09 06:38:22','2009-08-09 06:38:22');
INSERT INTO `currency_types` VALUES (17,'XCD','2009-08-09 06:38:31','2009-08-09 06:38:31');
INSERT INTO `currency_types` VALUES (18,'BYR','2009-08-09 06:38:39','2009-08-09 06:38:39');
INSERT INTO `currency_types` VALUES (19,'BZD','2009-08-09 06:38:52','2009-08-09 06:38:52');
INSERT INTO `currency_types` VALUES (20,'XOF','2009-08-09 06:39:02','2009-08-09 06:39:02');
INSERT INTO `currency_types` VALUES (21,'BMD','2009-08-09 06:39:11','2009-08-09 06:39:11');
INSERT INTO `currency_types` VALUES (22,'BTN','2009-08-09 06:39:22','2009-08-09 06:39:22');
INSERT INTO `currency_types` VALUES (23,'INR','2009-08-09 06:39:31','2009-08-09 06:39:31');
INSERT INTO `currency_types` VALUES (24,'BOB','2009-08-09 06:39:40','2009-08-09 06:39:40');
INSERT INTO `currency_types` VALUES (25,'ANG','2009-08-09 06:39:48','2009-08-09 06:39:48');
INSERT INTO `currency_types` VALUES (26,'BWP','2009-08-09 06:40:06','2009-08-09 06:40:06');
INSERT INTO `currency_types` VALUES (28,'BRL','2009-08-09 06:40:26','2009-08-09 06:40:26');
INSERT INTO `currency_types` VALUES (29,'GBP','2009-08-09 06:40:35','2009-08-09 06:40:35');
INSERT INTO `currency_types` VALUES (30,'BND','2009-08-09 06:41:20','2009-08-09 06:41:20');
INSERT INTO `currency_types` VALUES (31,'BGN','2009-08-09 06:42:05','2009-08-09 06:42:05');
INSERT INTO `currency_types` VALUES (33,'AED','2009-08-09 06:43:12','2009-08-09 06:43:12');
INSERT INTO `currency_types` VALUES (35,'BAM','2009-08-09 06:43:50','2009-08-09 06:43:50');
INSERT INTO `currency_types` VALUES (36,'BIF','2009-08-09 06:44:12','2009-08-09 06:44:12');
INSERT INTO `currency_types` VALUES (37,'CAD','2009-08-09 06:44:54','2009-08-09 06:44:54');
INSERT INTO `currency_types` VALUES (38,'CDF','2009-08-09 06:45:03','2009-08-09 06:45:03');
INSERT INTO `currency_types` VALUES (39,'CHF','2009-08-09 06:45:13','2009-08-09 06:45:13');
INSERT INTO `currency_types` VALUES (40,'CLP','2009-08-09 06:45:22','2009-08-09 06:45:22');
INSERT INTO `currency_types` VALUES (41,'CNY','2009-08-09 06:45:30','2009-08-09 06:45:30');
INSERT INTO `currency_types` VALUES (42,'COP','2009-08-09 06:45:39','2009-08-09 06:45:39');
INSERT INTO `currency_types` VALUES (43,'CRC','2009-08-09 06:45:50','2009-08-09 06:45:50');
INSERT INTO `currency_types` VALUES (44,'CUP','2009-08-09 06:45:57','2009-08-09 06:45:57');
INSERT INTO `currency_types` VALUES (45,'CVE','2009-08-09 06:46:07','2009-08-09 06:46:07');
INSERT INTO `currency_types` VALUES (46,'CYP','2009-08-09 06:46:20','2009-08-09 06:46:20');
INSERT INTO `currency_types` VALUES (47,'CZK','2009-08-09 06:46:28','2009-08-09 06:46:28');
INSERT INTO `currency_types` VALUES (48,'DJF','2009-08-09 06:46:43','2009-08-09 06:46:43');
INSERT INTO `currency_types` VALUES (49,'DKK','2009-08-09 06:46:55','2009-08-09 06:46:55');
INSERT INTO `currency_types` VALUES (50,'DOP','2009-08-09 06:47:03','2009-08-09 06:47:03');
INSERT INTO `currency_types` VALUES (51,'DZD','2009-08-09 06:47:14','2009-08-09 06:47:14');
INSERT INTO `currency_types` VALUES (52,'EEK','2009-08-09 06:47:33','2009-08-09 06:47:33');
INSERT INTO `currency_types` VALUES (53,'EGP','2009-08-09 06:47:42','2009-08-09 06:47:42');
INSERT INTO `currency_types` VALUES (54,'ERN','2009-08-09 06:47:51','2009-08-09 06:47:51');
INSERT INTO `currency_types` VALUES (55,'ETB','2009-08-09 06:48:02','2009-08-09 06:48:02');
INSERT INTO `currency_types` VALUES (56,'FJD','2009-08-09 06:48:16','2009-08-09 06:48:16');
INSERT INTO `currency_types` VALUES (57,'FKP','2009-08-09 06:48:27','2009-08-09 06:48:27');
INSERT INTO `currency_types` VALUES (58,'GEL','2009-08-09 06:48:36','2009-08-09 06:48:36');
INSERT INTO `currency_types` VALUES (59,'GGP','2009-08-09 06:48:43','2009-08-09 06:48:43');
INSERT INTO `currency_types` VALUES (60,'GHS','2009-08-09 06:48:52','2009-08-09 06:48:52');
INSERT INTO `currency_types` VALUES (61,'GIP','2009-08-09 06:49:05','2009-08-09 06:49:05');
INSERT INTO `currency_types` VALUES (62,'GMD','2009-08-09 06:49:13','2009-08-09 06:49:13');
INSERT INTO `currency_types` VALUES (63,'GNF','2009-08-09 06:49:22','2009-08-09 06:49:22');
INSERT INTO `currency_types` VALUES (64,'GTQ','2009-08-09 06:49:33','2009-08-09 06:49:33');
INSERT INTO `currency_types` VALUES (65,'GYD','2009-08-09 06:49:44','2009-08-09 06:49:44');
INSERT INTO `currency_types` VALUES (66,'HKD','2009-08-09 06:49:58','2009-08-09 06:49:58');
INSERT INTO `currency_types` VALUES (67,'HNL','2009-08-09 06:50:12','2009-08-09 06:50:12');
INSERT INTO `currency_types` VALUES (68,'HRK','2009-08-09 06:50:23','2009-08-09 06:50:23');
INSERT INTO `currency_types` VALUES (69,'HTG','2009-08-09 06:50:31','2009-08-09 06:50:31');
INSERT INTO `currency_types` VALUES (70,'HUF','2009-08-09 06:50:42','2009-08-09 06:50:57');
INSERT INTO `currency_types` VALUES (71,'IDR','2009-08-09 06:51:11','2009-08-09 06:51:11');
INSERT INTO `currency_types` VALUES (72,'ILS','2009-08-09 06:51:20','2009-08-09 06:51:20');
INSERT INTO `currency_types` VALUES (74,'IMP','2009-08-09 06:51:38','2009-08-09 06:51:38');
INSERT INTO `currency_types` VALUES (75,'IQD','2009-08-09 06:51:49','2009-08-09 06:51:49');
INSERT INTO `currency_types` VALUES (76,'IRR','2009-08-09 06:52:01','2009-08-09 06:52:01');
INSERT INTO `currency_types` VALUES (77,'ISK','2009-08-09 06:52:09','2009-08-09 06:52:09');
INSERT INTO `currency_types` VALUES (78,'JEP','2009-08-09 06:52:18','2009-08-09 06:52:18');
INSERT INTO `currency_types` VALUES (79,'JMD','2009-08-09 06:52:27','2009-08-09 06:52:27');
INSERT INTO `currency_types` VALUES (80,'JOD','2009-08-09 06:52:40','2009-08-09 06:52:40');
INSERT INTO `currency_types` VALUES (81,'JPY','2009-08-09 06:52:51','2009-08-09 06:52:51');
INSERT INTO `currency_types` VALUES (82,'KES','2009-08-09 06:52:59','2009-08-09 06:52:59');
INSERT INTO `currency_types` VALUES (83,'KGS','2009-08-09 06:53:11','2009-08-09 06:53:11');
INSERT INTO `currency_types` VALUES (84,'KHR','2009-08-09 06:53:20','2009-08-09 06:53:20');
INSERT INTO `currency_types` VALUES (85,'KMF','2009-08-09 06:53:33','2009-08-09 06:53:33');
INSERT INTO `currency_types` VALUES (86,'KPW','2009-08-09 06:53:43','2009-08-09 06:53:43');
INSERT INTO `currency_types` VALUES (87,'KRW','2009-08-09 06:53:52','2009-08-09 06:53:52');
INSERT INTO `currency_types` VALUES (88,'KWD','2009-08-09 06:54:00','2009-08-09 06:54:00');
INSERT INTO `currency_types` VALUES (89,'KYD','2009-08-09 06:54:11','2009-08-09 06:54:11');
INSERT INTO `currency_types` VALUES (90,'KZT','2009-08-09 06:54:23','2009-08-09 06:54:23');
INSERT INTO `currency_types` VALUES (91,'LAK','2009-08-09 06:54:34','2009-08-09 06:54:34');
INSERT INTO `currency_types` VALUES (92,'LBP','2009-08-09 06:54:43','2009-08-09 06:54:43');
INSERT INTO `currency_types` VALUES (93,'LKR','2009-08-09 06:55:02','2009-08-09 06:55:02');
INSERT INTO `currency_types` VALUES (94,'LRD','2009-08-09 06:58:19','2009-08-09 06:58:19');
INSERT INTO `currency_types` VALUES (95,'LSL','2009-08-09 06:58:28','2009-08-09 06:58:28');
INSERT INTO `currency_types` VALUES (96,'LTL','2009-08-09 06:58:36','2009-08-09 06:58:36');
INSERT INTO `currency_types` VALUES (97,'LVL','2009-08-09 06:58:49','2009-08-09 06:58:49');
INSERT INTO `currency_types` VALUES (98,'LYD','2009-08-09 06:58:58','2009-08-09 06:58:58');
INSERT INTO `currency_types` VALUES (99,'MAD','2009-08-09 06:59:07','2009-08-09 06:59:07');
INSERT INTO `currency_types` VALUES (100,'MDL','2009-08-09 06:59:21','2009-08-09 06:59:21');
INSERT INTO `currency_types` VALUES (101,'MGA','2009-08-09 06:59:30','2009-08-09 06:59:30');
INSERT INTO `currency_types` VALUES (102,'MKD','2009-08-09 06:59:43','2009-08-09 06:59:43');
INSERT INTO `currency_types` VALUES (103,'MMK','2009-08-09 06:59:52','2009-08-09 06:59:52');
INSERT INTO `currency_types` VALUES (104,'MNT','2009-08-09 07:00:06','2009-08-09 07:00:06');
INSERT INTO `currency_types` VALUES (105,'MOP','2009-08-09 07:13:32','2009-08-09 07:13:32');
INSERT INTO `currency_types` VALUES (106,'MRO','2009-08-09 07:13:43','2009-08-09 07:13:43');
INSERT INTO `currency_types` VALUES (107,'MTL','2009-08-09 07:13:51','2009-08-09 07:13:51');
INSERT INTO `currency_types` VALUES (108,'MUR','2009-08-09 07:14:01','2009-08-09 07:14:01');
INSERT INTO `currency_types` VALUES (109,'MVR','2009-08-09 07:14:10','2009-08-09 07:14:10');
INSERT INTO `currency_types` VALUES (110,'MWK','2009-08-09 07:14:22','2009-08-09 07:14:22');
INSERT INTO `currency_types` VALUES (111,'MXN','2009-08-09 07:14:30','2009-08-09 07:14:30');
INSERT INTO `currency_types` VALUES (112,'MYR','2009-08-09 07:14:45','2009-08-09 07:14:45');
INSERT INTO `currency_types` VALUES (113,'MZN','2009-08-09 07:14:55','2009-08-09 07:14:55');
INSERT INTO `currency_types` VALUES (114,'NAD','2009-08-09 07:15:12','2009-08-09 07:15:12');
INSERT INTO `currency_types` VALUES (115,'NGN','2009-08-09 07:15:21','2009-08-09 07:15:21');
INSERT INTO `currency_types` VALUES (116,'NIO','2009-08-09 07:15:33','2009-08-09 07:15:33');
INSERT INTO `currency_types` VALUES (117,'NOK','2009-08-09 07:15:41','2009-08-09 07:15:41');
INSERT INTO `currency_types` VALUES (118,'NPR','2009-08-09 07:15:51','2009-08-09 07:15:51');
INSERT INTO `currency_types` VALUES (119,'NZD','2009-08-09 07:16:06','2009-08-09 07:16:06');
INSERT INTO `currency_types` VALUES (120,'OMR','2009-08-09 07:16:18','2009-08-09 07:16:18');
INSERT INTO `currency_types` VALUES (121,'PAB','2009-08-09 07:16:29','2009-08-09 07:16:29');
INSERT INTO `currency_types` VALUES (122,'PEN','2009-08-09 07:16:38','2009-08-09 07:16:38');
INSERT INTO `currency_types` VALUES (123,'PGK','2009-08-09 07:16:49','2009-08-09 07:16:49');
INSERT INTO `currency_types` VALUES (124,'PHP','2009-08-09 07:16:59','2009-08-09 07:16:59');
INSERT INTO `currency_types` VALUES (125,'PKR','2009-08-09 07:17:11','2009-08-09 07:17:11');
INSERT INTO `currency_types` VALUES (126,'PLN','2009-08-09 07:17:23','2009-08-09 07:17:23');
INSERT INTO `currency_types` VALUES (127,'PYG','2009-08-09 07:17:32','2009-08-09 07:17:32');
INSERT INTO `currency_types` VALUES (128,'QAR','2009-08-09 07:17:44','2009-08-09 07:17:44');
INSERT INTO `currency_types` VALUES (129,'RON','2009-08-09 07:19:01','2009-08-09 07:19:01');
INSERT INTO `currency_types` VALUES (130,'RSD','2009-08-09 07:19:19','2009-08-09 07:19:19');
INSERT INTO `currency_types` VALUES (131,'RUB','2009-08-09 07:19:32','2009-08-09 07:19:32');
INSERT INTO `currency_types` VALUES (132,'RWF','2009-08-09 07:19:43','2009-08-09 07:19:43');
INSERT INTO `currency_types` VALUES (133,'SAR','2009-08-09 07:19:56','2009-08-09 07:19:56');
INSERT INTO `currency_types` VALUES (134,'SBD','2009-08-09 07:20:09','2009-08-09 07:20:09');
INSERT INTO `currency_types` VALUES (135,'SCR','2009-08-09 07:20:19','2009-08-09 07:20:19');
INSERT INTO `currency_types` VALUES (136,'SDG','2009-08-09 07:20:27','2009-08-09 07:20:27');
INSERT INTO `currency_types` VALUES (137,'SEK','2009-08-09 07:20:35','2009-08-09 07:20:35');
INSERT INTO `currency_types` VALUES (138,'SGD','2009-08-09 07:20:46','2009-08-09 07:20:46');
INSERT INTO `currency_types` VALUES (139,'SLL','2009-08-09 07:20:59','2009-08-09 07:20:59');
INSERT INTO `currency_types` VALUES (140,'SOS','2009-08-09 07:21:09','2009-08-09 07:21:09');
INSERT INTO `currency_types` VALUES (141,'SPL','2009-08-09 07:21:20','2009-08-09 07:21:20');
INSERT INTO `currency_types` VALUES (142,'SRD','2009-08-09 07:21:33','2009-08-09 07:21:33');
INSERT INTO `currency_types` VALUES (143,'STD','2009-08-09 07:21:46','2009-08-09 07:21:46');
INSERT INTO `currency_types` VALUES (144,'SVC','2009-08-09 07:21:56','2009-08-09 07:21:56');
INSERT INTO `currency_types` VALUES (145,'SYP','2009-08-09 07:22:06','2009-08-09 07:22:06');
INSERT INTO `currency_types` VALUES (146,'SZL','2009-08-09 07:22:22','2009-08-09 07:22:22');
INSERT INTO `currency_types` VALUES (147,'THB','2009-08-09 07:22:34','2009-08-09 07:22:34');
INSERT INTO `currency_types` VALUES (148,'TJS','2009-08-09 07:22:45','2009-08-09 07:22:45');
INSERT INTO `currency_types` VALUES (149,'TMM','2009-08-09 07:22:55','2009-08-09 07:22:55');
INSERT INTO `currency_types` VALUES (150,'TND','2009-08-09 07:23:06','2009-08-09 07:23:06');
INSERT INTO `currency_types` VALUES (151,'TOP','2009-08-09 07:23:18','2009-08-09 07:23:18');
INSERT INTO `currency_types` VALUES (152,'TRY','2009-08-09 07:23:35','2009-08-09 07:23:35');
INSERT INTO `currency_types` VALUES (153,'TTD','2009-08-09 07:23:47','2009-08-09 07:23:47');
INSERT INTO `currency_types` VALUES (154,'TVD','2009-08-09 07:23:57','2009-08-09 07:23:57');
INSERT INTO `currency_types` VALUES (155,'TWD','2009-08-09 07:24:10','2009-08-09 07:24:10');
INSERT INTO `currency_types` VALUES (156,'TZS','2009-08-09 07:24:21','2009-08-09 07:24:21');
INSERT INTO `currency_types` VALUES (157,'UAH','2009-08-09 07:24:37','2009-08-09 07:24:37');
INSERT INTO `currency_types` VALUES (158,'UGX','2009-08-09 07:24:49','2009-08-09 07:24:49');
INSERT INTO `currency_types` VALUES (159,'UYU','2009-08-09 07:24:59','2009-08-09 07:24:59');
INSERT INTO `currency_types` VALUES (160,'UZS','2009-08-09 07:25:10','2009-08-09 07:25:10');
INSERT INTO `currency_types` VALUES (161,'VEF','2009-08-09 07:25:21','2009-08-09 07:25:48');
INSERT INTO `currency_types` VALUES (162,'VND','2009-08-09 07:26:06','2009-08-09 07:26:06');
INSERT INTO `currency_types` VALUES (163,'VUV','2009-08-09 07:26:23','2009-08-09 07:26:23');
INSERT INTO `currency_types` VALUES (164,'WST','2009-08-09 07:26:35','2009-08-09 07:26:35');
INSERT INTO `currency_types` VALUES (165,'XAF','2009-08-09 07:26:53','2009-08-09 07:26:53');
INSERT INTO `currency_types` VALUES (166,'XAG','2009-08-09 07:27:08','2009-08-09 07:27:08');
INSERT INTO `currency_types` VALUES (167,'XAU','2009-08-09 07:27:19','2009-08-09 07:27:19');
INSERT INTO `currency_types` VALUES (169,'XCD','2009-08-09 07:30:52','2009-08-09 07:30:52');
INSERT INTO `currency_types` VALUES (170,'XDR','2009-08-09 07:31:03','2009-08-09 07:31:03');
INSERT INTO `currency_types` VALUES (171,'XPD','2009-08-09 07:31:18','2009-08-09 07:31:18');
INSERT INTO `currency_types` VALUES (172,'XPF','2009-08-09 07:31:30','2009-08-09 07:31:30');
INSERT INTO `currency_types` VALUES (173,'XPT','2009-08-09 07:31:40','2009-08-09 07:31:40');
INSERT INTO `currency_types` VALUES (174,'YER','2009-08-09 07:31:50','2009-08-09 07:31:50');
INSERT INTO `currency_types` VALUES (175,'ZAR','2009-08-09 07:32:15','2009-08-09 07:32:15');
INSERT INTO `currency_types` VALUES (176,'ZMK','2009-08-09 07:32:24','2009-08-09 07:32:24');
INSERT INTO `currency_types` VALUES (177,'ZWD','2009-08-09 07:32:35','2009-08-09 07:32:35');
/*!40000 ALTER TABLE `currency_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donations`
--

DROP TABLE IF EXISTS `donations`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `donations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `donor_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `amount` int(11) DEFAULT NULL,
  `donation_attribution_id` int(11) DEFAULT NULL,
  `donated_at` datetime DEFAULT NULL,
  `receipt_sent_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `zip` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `tip_percentage` int(11) DEFAULT '0',
  `mailing_list` tinyint(1) DEFAULT '0',
  `anonymous` tinyint(1) DEFAULT '0',
  `order_id` varchar(255) DEFAULT NULL,
  `authorization_code` varchar(255) DEFAULT NULL,
  `actual_amount` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `donations`
--

LOCK TABLES `donations` WRITE;
/*!40000 ALTER TABLE `donations` DISABLE KEYS */;
INSERT INTO `donations` VALUES (1,1,1,20,3,'2009-08-09 06:03:00','2009-08-09 06:03:00','2009-08-09 06:04:01','2009-08-09 08:29:39',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL);
INSERT INTO `donations` VALUES (2,1,1,0,3,'2009-08-12 11:13:00','2009-08-16 06:03:00','2009-08-09 06:04:20','2009-08-09 07:11:05',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,NULL,NULL,NULL);
/*!40000 ALTER TABLE `donations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `donors`
--

DROP TABLE IF EXISTS `donors`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `donors` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `zip` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `donors`
--

LOCK TABLES `donors` WRITE;
/*!40000 ALTER TABLE `donors` DISABLE KEYS */;
INSERT INTO `donors` VALUES (1,3,'Matthew Moore','123 Philanthropy Way','','Charityville','CA','12345','goodguy@donations.example.com','','2009-08-09 07:10:51','2009-08-09 07:10:51');
/*!40000 ALTER TABLE `donors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `focus_areas`
--

DROP TABLE IF EXISTS `focus_areas`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `focus_areas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `focus_areas`
--

LOCK TABLES `focus_areas` WRITE;
/*!40000 ALTER TABLE `focus_areas` DISABLE KEYS */;
INSERT INTO `focus_areas` VALUES (1,'Food/Security','2009-08-09 05:50:26','2009-08-09 05:50:26');
INSERT INTO `focus_areas` VALUES (2,'Water & Sanitation','2009-08-09 05:50:52','2009-08-09 05:50:52');
INSERT INTO `focus_areas` VALUES (3,'Education','2009-08-09 05:51:01','2009-08-09 05:51:01');
INSERT INTO `focus_areas` VALUES (4,'Clean Energy','2009-08-09 05:51:12','2009-08-09 05:51:12');
INSERT INTO `focus_areas` VALUES (5,'Healthcare','2009-08-09 05:51:20','2009-08-13 20:29:01');
/*!40000 ALTER TABLE `focus_areas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fundraising_goal_ranges`
--

DROP TABLE IF EXISTS `fundraising_goal_ranges`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `fundraising_goal_ranges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display_name` varchar(255) DEFAULT NULL,
  `min_value` int(11) DEFAULT NULL,
  `max_value` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `fundraising_goal_ranges`
--

LOCK TABLES `fundraising_goal_ranges` WRITE;
/*!40000 ALTER TABLE `fundraising_goal_ranges` DISABLE KEYS */;
INSERT INTO `fundraising_goal_ranges` VALUES (1,'$0 - $5,000',0,5000,'2009-09-13 16:25:39','2009-09-13 16:25:39');
INSERT INTO `fundraising_goal_ranges` VALUES (2,'$5,000 - $10,000',5001,10000,'2009-09-13 16:25:39','2009-09-13 16:25:39');
INSERT INTO `fundraising_goal_ranges` VALUES (3,'> $10,000',10000,NULL,'2009-09-13 16:25:39','2009-09-13 16:25:39');
/*!40000 ALTER TABLE `fundraising_goal_ranges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `imported_contacts`
--

DROP TABLE IF EXISTS `imported_contacts`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `imported_contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `referrer_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `referral_code` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `imported_contacts`
--

LOCK TABLES `imported_contacts` WRITE;
/*!40000 ALTER TABLE `imported_contacts` DISABLE KEYS */;
/*!40000 ALTER TABLE `imported_contacts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lives_impacted_ranges`
--

DROP TABLE IF EXISTS `lives_impacted_ranges`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `lives_impacted_ranges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display_name` varchar(255) DEFAULT NULL,
  `min_value` int(11) DEFAULT NULL,
  `max_value` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `lives_impacted_ranges`
--

LOCK TABLES `lives_impacted_ranges` WRITE;
/*!40000 ALTER TABLE `lives_impacted_ranges` DISABLE KEYS */;
INSERT INTO `lives_impacted_ranges` VALUES (1,'0 - 500',0,500,'2009-09-13 16:25:37','2009-09-13 16:25:37');
INSERT INTO `lives_impacted_ranges` VALUES (2,'500 - 1000',501,1000,'2009-09-13 16:25:37','2009-09-13 16:25:37');
INSERT INTO `lives_impacted_ranges` VALUES (3,'> 1000',1000,NULL,'2009-09-13 16:25:37','2009-09-13 16:25:37');
/*!40000 ALTER TABLE `lives_impacted_ranges` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `messages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_id` int(11) DEFAULT NULL,
  `recipient_id` int(11) DEFAULT NULL,
  `sender_deleted` tinyint(1) DEFAULT '0',
  `recipient_deleted` tinyint(1) DEFAULT '0',
  `subject` varchar(255) DEFAULT NULL,
  `body` text,
  `read_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `news_items`
--

DROP TABLE IF EXISTS `news_items`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `news_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `newsable_type` varchar(255) DEFAULT NULL,
  `newsable_id` int(11) DEFAULT NULL,
  `news_item_type` varchar(255) DEFAULT NULL,
  `news_message` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `news_items`
--

LOCK TABLES `news_items` WRITE;
/*!40000 ALTER TABLE `news_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `news_items` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ngo_admin_associations`
--

DROP TABLE IF EXISTS `ngo_admin_associations`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ngo_admin_associations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `ngo_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ngo_admin_associations`
--

LOCK TABLES `ngo_admin_associations` WRITE;
/*!40000 ALTER TABLE `ngo_admin_associations` DISABLE KEYS */;
INSERT INTO `ngo_admin_associations` VALUES (1,2,2,'2009-08-09 05:54:37','2009-08-09 05:54:37');
INSERT INTO `ngo_admin_associations` VALUES (2,3,1,'2009-08-09 05:55:49','2009-08-09 05:55:49');
INSERT INTO `ngo_admin_associations` VALUES (3,10,4,'2009-08-20 03:19:31','2009-08-20 03:19:31');
/*!40000 ALTER TABLE `ngo_admin_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ngo_coordinator_associations`
--

DROP TABLE IF EXISTS `ngo_coordinator_associations`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ngo_coordinator_associations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=76 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ngo_coordinator_associations`
--

LOCK TABLES `ngo_coordinator_associations` WRITE;
/*!40000 ALTER TABLE `ngo_coordinator_associations` DISABLE KEYS */;
INSERT INTO `ngo_coordinator_associations` VALUES (1,NULL,1,'2009-08-09 07:36:06','2009-08-09 07:36:06');
INSERT INTO `ngo_coordinator_associations` VALUES (2,NULL,NULL,'2009-08-17 14:16:34','2009-08-17 14:16:34');
INSERT INTO `ngo_coordinator_associations` VALUES (3,NULL,NULL,'2009-08-17 14:16:50','2009-08-17 14:16:50');
INSERT INTO `ngo_coordinator_associations` VALUES (4,NULL,NULL,'2009-08-17 14:26:04','2009-08-17 14:26:04');
INSERT INTO `ngo_coordinator_associations` VALUES (5,NULL,NULL,'2009-08-17 14:31:00','2009-08-17 14:31:00');
INSERT INTO `ngo_coordinator_associations` VALUES (6,NULL,NULL,'2009-08-17 14:34:08','2009-08-17 14:34:08');
INSERT INTO `ngo_coordinator_associations` VALUES (7,NULL,NULL,'2009-08-17 14:37:16','2009-08-17 14:37:16');
INSERT INTO `ngo_coordinator_associations` VALUES (8,NULL,NULL,'2009-08-17 14:43:27','2009-08-17 14:43:27');
INSERT INTO `ngo_coordinator_associations` VALUES (9,NULL,NULL,'2009-08-17 14:44:02','2009-08-17 14:44:02');
INSERT INTO `ngo_coordinator_associations` VALUES (10,NULL,NULL,'2009-08-17 14:49:17','2009-08-17 14:49:17');
INSERT INTO `ngo_coordinator_associations` VALUES (11,NULL,10,'2009-08-17 14:50:28','2009-08-17 14:50:28');
INSERT INTO `ngo_coordinator_associations` VALUES (12,NULL,NULL,'2009-08-17 14:50:49','2009-08-17 14:50:49');
INSERT INTO `ngo_coordinator_associations` VALUES (13,NULL,NULL,'2009-08-17 14:52:59','2009-08-17 14:52:59');
INSERT INTO `ngo_coordinator_associations` VALUES (14,NULL,NULL,'2009-08-17 14:53:08','2009-08-17 14:53:08');
INSERT INTO `ngo_coordinator_associations` VALUES (15,NULL,NULL,'2009-08-17 14:55:45','2009-08-17 14:55:45');
INSERT INTO `ngo_coordinator_associations` VALUES (16,NULL,NULL,'2009-08-17 14:56:38','2009-08-17 14:56:38');
INSERT INTO `ngo_coordinator_associations` VALUES (17,NULL,14,'2009-08-17 14:57:29','2009-08-17 14:57:29');
INSERT INTO `ngo_coordinator_associations` VALUES (18,NULL,NULL,'2009-08-17 14:57:45','2009-08-17 14:57:45');
INSERT INTO `ngo_coordinator_associations` VALUES (19,NULL,NULL,'2009-08-17 15:02:14','2009-08-17 15:02:14');
INSERT INTO `ngo_coordinator_associations` VALUES (20,NULL,6,'2009-08-17 15:02:20','2009-08-17 15:02:20');
INSERT INTO `ngo_coordinator_associations` VALUES (21,NULL,NULL,'2009-08-17 15:03:06','2009-08-17 15:03:06');
INSERT INTO `ngo_coordinator_associations` VALUES (22,NULL,17,'2009-08-17 15:04:20','2009-08-17 15:04:20');
INSERT INTO `ngo_coordinator_associations` VALUES (23,NULL,4,'2009-08-17 15:06:23','2009-08-17 15:06:23');
INSERT INTO `ngo_coordinator_associations` VALUES (24,NULL,NULL,'2009-08-17 15:09:54','2009-08-17 15:09:54');
INSERT INTO `ngo_coordinator_associations` VALUES (25,NULL,NULL,'2009-08-17 15:13:57','2009-08-17 15:13:57');
INSERT INTO `ngo_coordinator_associations` VALUES (26,NULL,19,'2009-08-17 15:14:13','2009-08-17 15:14:13');
INSERT INTO `ngo_coordinator_associations` VALUES (27,NULL,NULL,'2009-08-17 15:14:14','2009-08-17 15:14:14');
INSERT INTO `ngo_coordinator_associations` VALUES (28,NULL,NULL,'2009-08-17 15:23:31','2009-08-17 15:23:31');
INSERT INTO `ngo_coordinator_associations` VALUES (29,NULL,21,'2009-08-17 15:24:29','2009-08-17 15:24:29');
INSERT INTO `ngo_coordinator_associations` VALUES (30,NULL,NULL,'2009-08-17 15:25:28','2009-08-17 15:25:28');
INSERT INTO `ngo_coordinator_associations` VALUES (31,NULL,NULL,'2009-08-17 15:26:53','2009-08-17 15:26:53');
INSERT INTO `ngo_coordinator_associations` VALUES (32,NULL,23,'2009-08-17 15:27:04','2009-08-17 15:27:04');
INSERT INTO `ngo_coordinator_associations` VALUES (33,NULL,NULL,'2009-08-17 15:27:44','2009-08-17 15:27:44');
INSERT INTO `ngo_coordinator_associations` VALUES (34,NULL,NULL,'2009-08-17 15:29:32','2009-08-17 15:29:32');
INSERT INTO `ngo_coordinator_associations` VALUES (35,NULL,25,'2009-08-17 15:29:57','2009-08-17 15:29:57');
INSERT INTO `ngo_coordinator_associations` VALUES (36,NULL,NULL,'2009-08-17 15:31:07','2009-08-17 15:31:07');
INSERT INTO `ngo_coordinator_associations` VALUES (37,NULL,NULL,'2009-08-17 15:33:45','2009-08-17 15:33:45');
INSERT INTO `ngo_coordinator_associations` VALUES (38,NULL,NULL,'2009-08-17 15:37:11','2009-08-17 15:37:11');
INSERT INTO `ngo_coordinator_associations` VALUES (39,NULL,NULL,'2009-08-17 15:40:29','2009-08-17 15:40:29');
INSERT INTO `ngo_coordinator_associations` VALUES (40,NULL,29,'2009-08-17 15:43:01','2009-08-17 15:43:01');
INSERT INTO `ngo_coordinator_associations` VALUES (41,NULL,15,'2009-08-17 15:44:25','2009-08-17 15:44:25');
INSERT INTO `ngo_coordinator_associations` VALUES (42,NULL,22,'2009-08-17 15:45:11','2009-08-17 15:45:11');
INSERT INTO `ngo_coordinator_associations` VALUES (43,NULL,24,'2009-08-17 15:45:36','2009-08-17 15:45:36');
INSERT INTO `ngo_coordinator_associations` VALUES (44,NULL,NULL,'2009-08-17 15:45:54','2009-08-17 15:45:54');
INSERT INTO `ngo_coordinator_associations` VALUES (45,NULL,NULL,'2009-08-17 15:47:33','2009-08-17 15:47:33');
INSERT INTO `ngo_coordinator_associations` VALUES (46,NULL,NULL,'2009-08-17 15:50:32','2009-08-17 15:50:32');
INSERT INTO `ngo_coordinator_associations` VALUES (47,NULL,NULL,'2009-08-17 15:50:37','2009-08-17 15:50:37');
INSERT INTO `ngo_coordinator_associations` VALUES (48,NULL,NULL,'2009-08-17 15:52:10','2009-08-17 15:52:10');
INSERT INTO `ngo_coordinator_associations` VALUES (49,NULL,34,'2009-08-17 15:53:13','2009-08-17 15:53:13');
INSERT INTO `ngo_coordinator_associations` VALUES (50,NULL,NULL,'2009-08-17 15:53:24','2009-08-17 15:53:24');
INSERT INTO `ngo_coordinator_associations` VALUES (51,NULL,NULL,'2009-08-17 15:53:39','2009-08-17 15:53:39');
INSERT INTO `ngo_coordinator_associations` VALUES (52,NULL,NULL,'2009-08-17 15:55:01','2009-08-17 15:55:01');
INSERT INTO `ngo_coordinator_associations` VALUES (53,NULL,36,'2009-08-17 15:55:42','2009-08-17 15:55:42');
INSERT INTO `ngo_coordinator_associations` VALUES (54,NULL,NULL,'2009-08-17 15:56:54','2009-08-17 15:56:54');
INSERT INTO `ngo_coordinator_associations` VALUES (55,NULL,NULL,'2009-08-17 15:58:36','2009-08-17 15:58:36');
INSERT INTO `ngo_coordinator_associations` VALUES (56,NULL,NULL,'2009-08-17 15:59:13','2009-08-17 15:59:13');
INSERT INTO `ngo_coordinator_associations` VALUES (57,NULL,39,'2009-08-17 15:59:38','2009-08-17 15:59:38');
INSERT INTO `ngo_coordinator_associations` VALUES (58,NULL,NULL,'2009-08-17 16:00:43','2009-08-17 16:00:43');
INSERT INTO `ngo_coordinator_associations` VALUES (59,NULL,NULL,'2009-08-17 16:04:34','2009-08-17 16:04:34');
INSERT INTO `ngo_coordinator_associations` VALUES (60,NULL,NULL,'2009-08-17 16:04:50','2009-08-17 16:04:50');
INSERT INTO `ngo_coordinator_associations` VALUES (61,NULL,NULL,'2009-08-17 16:09:21','2009-08-17 16:09:21');
INSERT INTO `ngo_coordinator_associations` VALUES (62,NULL,42,'2009-08-17 16:10:19','2009-08-17 16:10:19');
INSERT INTO `ngo_coordinator_associations` VALUES (63,NULL,NULL,'2009-08-17 16:15:02','2009-08-17 16:15:02');
INSERT INTO `ngo_coordinator_associations` VALUES (64,NULL,20,'2009-08-21 16:38:25','2009-08-21 16:38:25');
INSERT INTO `ngo_coordinator_associations` VALUES (65,NULL,32,'2009-08-21 18:01:55','2009-08-21 18:01:55');
INSERT INTO `ngo_coordinator_associations` VALUES (66,NULL,31,'2009-08-21 18:53:37','2009-08-21 18:53:37');
INSERT INTO `ngo_coordinator_associations` VALUES (67,NULL,33,'2009-08-21 19:46:06','2009-08-21 19:46:06');
INSERT INTO `ngo_coordinator_associations` VALUES (68,NULL,43,'2009-08-21 20:16:00','2009-08-21 20:16:00');
INSERT INTO `ngo_coordinator_associations` VALUES (69,NULL,13,'2009-08-21 20:29:58','2009-08-21 20:29:58');
INSERT INTO `ngo_coordinator_associations` VALUES (70,NULL,NULL,'2009-08-25 16:02:34','2009-08-25 16:02:34');
INSERT INTO `ngo_coordinator_associations` VALUES (71,NULL,44,'2009-08-25 16:12:07','2009-08-25 16:12:07');
INSERT INTO `ngo_coordinator_associations` VALUES (72,NULL,NULL,'2009-08-25 16:41:26','2009-08-25 16:41:26');
INSERT INTO `ngo_coordinator_associations` VALUES (73,NULL,NULL,'2009-08-25 16:41:52','2009-08-25 16:41:52');
INSERT INTO `ngo_coordinator_associations` VALUES (74,NULL,45,'2009-08-25 16:45:00','2009-08-25 16:45:00');
INSERT INTO `ngo_coordinator_associations` VALUES (75,NULL,11,'2009-08-25 19:05:56','2009-08-25 19:05:56');
/*!40000 ALTER TABLE `ngo_coordinator_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ngo_country_associations`
--

DROP TABLE IF EXISTS `ngo_country_associations`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ngo_country_associations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `country_id` int(11) DEFAULT NULL,
  `ngo_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ngo_country_associations`
--

LOCK TABLES `ngo_country_associations` WRITE;
/*!40000 ALTER TABLE `ngo_country_associations` DISABLE KEYS */;
INSERT INTO `ngo_country_associations` VALUES (1,1,1,'2009-08-09 09:52:03','2009-08-09 09:52:03');
INSERT INTO `ngo_country_associations` VALUES (2,2,3,'2009-08-09 10:00:59','2009-08-09 10:00:59');
INSERT INTO `ngo_country_associations` VALUES (3,1,4,'2009-08-09 10:01:37','2009-08-09 10:01:37');
/*!40000 ALTER TABLE `ngo_country_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ngo_focus_area_associations`
--

DROP TABLE IF EXISTS `ngo_focus_area_associations`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ngo_focus_area_associations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `focus_area_id` int(11) DEFAULT NULL,
  `ngo_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ngo_focus_area_associations`
--

LOCK TABLES `ngo_focus_area_associations` WRITE;
/*!40000 ALTER TABLE `ngo_focus_area_associations` DISABLE KEYS */;
INSERT INTO `ngo_focus_area_associations` VALUES (1,1,1,'2009-08-09 05:56:37','2009-08-09 05:56:37');
INSERT INTO `ngo_focus_area_associations` VALUES (2,3,4,'2009-08-20 02:56:29','2009-08-20 02:56:41');
INSERT INTO `ngo_focus_area_associations` VALUES (3,1,3,'2009-08-20 02:57:25','2009-08-20 02:57:25');
INSERT INTO `ngo_focus_area_associations` VALUES (4,2,3,'2009-08-20 02:57:35','2009-08-20 02:57:35');
INSERT INTO `ngo_focus_area_associations` VALUES (5,3,3,'2009-08-20 02:57:43','2009-08-20 02:57:43');
INSERT INTO `ngo_focus_area_associations` VALUES (6,4,3,'2009-08-20 02:57:51','2009-08-20 02:57:51');
INSERT INTO `ngo_focus_area_associations` VALUES (7,5,4,'2009-08-20 02:58:12','2009-08-20 02:58:12');
/*!40000 ALTER TABLE `ngo_focus_area_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ngo_user_details`
--

DROP TABLE IF EXISTS `ngo_user_details`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ngo_user_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `necessary` tinyint(1) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ngo_user_details`
--

LOCK TABLES `ngo_user_details` WRITE;
/*!40000 ALTER TABLE `ngo_user_details` DISABLE KEYS */;
/*!40000 ALTER TABLE `ngo_user_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ngos`
--

DROP TABLE IF EXISTS `ngos`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `ngos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display_name` varchar(255) DEFAULT NULL,
  `full_name` varchar(255) DEFAULT NULL,
  `permalink` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `public_email` varchar(255) DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `zip` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `fax_number` varchar(255) DEFAULT NULL,
  `details_for_website` text,
  `logo_file_name` varchar(255) DEFAULT NULL,
  `logo_content_type` varchar(255) DEFAULT NULL,
  `logo_file_size` varchar(255) DEFAULT NULL,
  `logo_updated_at` varchar(255) DEFAULT NULL,
  `representative_picture_file_name` varchar(255) DEFAULT NULL,
  `representative_picture_content_type` varchar(255) DEFAULT NULL,
  `representative_picture_file_size` varchar(255) DEFAULT NULL,
  `representative_picture_updated_at` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `ngos`
--

LOCK TABLES `ngos` WRITE;
/*!40000 ALTER TABLE `ngos` DISABLE KEYS */;
INSERT INTO `ngos` VALUES (3,'SEWA','Self Employed Women’s Association','sewa','http://www.sewa.org/','mail@sewa.org','SEWA Reception Centre','Opp. Victoria Garden','Bhadra','Ahmedabad','380 001','India','91-79-25506444','91-79-25506446','<p>The Self Employed Women’s Association (SEWA) is a trade union of 1,000,000 poor, self-employed women workers founded by Ela Bhatt in 1972. This informal, unorganized labor group is 93% of the labor force. They do not have the rights and protection under the law afforded to formal businesses, and women workers themselves remain undercounted and invisible. However, SEWA has set about changing that for over 30 years.\r\n</p>\r\n<p>\r\nSEWA’s main goals are to organize women workers for full employment & self-reliance. Full employment means employment whereby workers obtain work security, income security, food security and social security (at least health care, child care and shelter). SEWA organizes women to ensure that every family obtains full employment. SEWA strives for a woman’s self-reliance so she can be autonomous and self-reliant.</p>','partner_logo_sewa.jpg','image/jpeg','5427','2009-08-09 09:57:36','partner_image_sewa.jpg','image/jpeg','23578','2009-08-09 09:57:36','2009-08-09 09:57:36','2009-08-11 18:32:13');
INSERT INTO `ngos` VALUES (4,'Coprodeli USA','Coprodeli USA','coprodeli-usa','http://www.coprodeliusa.org/','','3124 N 10th Street','Suite 5 ','Arlington','VA','22201','USA','443-722-8682','','<p>Coprodeli USA is a 501(c)3 nonprofit organization that aids Peruvian families by providing fundamental needs, promoting education and job training, and developing strong self-sustaining community programs. Founded in 2000, Coprodeli USA supports the innovative grassroots development work carried out by Coprodeli Peru to serve poor and marginalized areas surrounding Lima, and throughout the earthquake-devastated Ica Region. Coprodeli has carried out more than 140 projects, benefiting more than 110,000 people annually in some of the most impoverished communities in Peru.\r\n</p><p>\r\n1Well is running a pilot project with Coprodeli to support the nutrition program of the Subtanjalla District Youth Outreach Center (Centro de Atención Externa-CAE) in Ica, Peru.</p>','coprodeli_logo.png','image/png','115388','2009-08-20 02:56:05','partner_image_coprodeli.jpg','image/jpeg','37386','2009-08-20 02:56:05','2009-08-09 10:00:34','2009-08-20 02:56:05');
/*!40000 ALTER TABLE `ngos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `permissions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `permissions`
--

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'approve_projects','Can this user give projects the go ahead?','2009-08-08 02:38:35','2009-08-08 02:38:35');
INSERT INTO `permissions` VALUES (2,'delete_projects','Can this user delete all projects in the system?','2009-08-08 02:38:35','2009-08-08 02:38:35');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_audios`
--

DROP TABLE IF EXISTS `project_audios`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `project_audios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `audio_file_name` varchar(255) DEFAULT NULL,
  `audio_content_type` varchar(255) DEFAULT NULL,
  `audio_file_size` varchar(255) DEFAULT NULL,
  `audio_updated_at` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `project_status_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `project_audios`
--

LOCK TABLES `project_audios` WRITE;
/*!40000 ALTER TABLE `project_audios` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_audios` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_events`
--

DROP TABLE IF EXISTS `project_events`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `project_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `host` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `short_description` varchar(255) DEFAULT NULL,
  `long_description` text,
  `event_start_time` datetime DEFAULT NULL,
  `event_end_time` datetime DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `zip` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `lat` float DEFAULT NULL,
  `lng` float DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `project_events`
--

LOCK TABLES `project_events` WRITE;
/*!40000 ALTER TABLE `project_events` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_focus_area_associations`
--

DROP TABLE IF EXISTS `project_focus_area_associations`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `project_focus_area_associations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `focus_area_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `project_focus_area_associations`
--

LOCK TABLES `project_focus_area_associations` WRITE;
/*!40000 ALTER TABLE `project_focus_area_associations` DISABLE KEYS */;
INSERT INTO `project_focus_area_associations` VALUES (1,1,2,'2009-08-09 06:04:45','2009-08-09 06:04:45');
INSERT INTO `project_focus_area_associations` VALUES (2,2,3,'2009-08-09 06:21:13','2009-08-09 06:21:13');
INSERT INTO `project_focus_area_associations` VALUES (3,1,4,'2009-08-09 09:10:41','2009-08-09 09:10:41');
INSERT INTO `project_focus_area_associations` VALUES (4,1,3,'2009-08-09 09:15:57','2009-08-09 09:15:57');
INSERT INTO `project_focus_area_associations` VALUES (5,5,2,'2009-08-17 21:26:15','2009-08-17 21:26:15');
INSERT INTO `project_focus_area_associations` VALUES (6,4,2,'2009-08-17 21:28:33','2009-08-17 21:28:33');
INSERT INTO `project_focus_area_associations` VALUES (7,33,3,'2009-08-20 17:37:13','2009-08-20 17:37:13');
INSERT INTO `project_focus_area_associations` VALUES (8,31,3,'2009-08-25 15:11:35','2009-08-25 15:11:35');
INSERT INTO `project_focus_area_associations` VALUES (9,20,3,'2009-08-25 15:39:28','2009-08-25 15:39:28');
INSERT INTO `project_focus_area_associations` VALUES (10,44,3,'2009-08-25 16:02:42','2009-08-25 16:02:42');
INSERT INTO `project_focus_area_associations` VALUES (11,32,3,'2009-08-25 16:13:27','2009-08-25 16:13:27');
INSERT INTO `project_focus_area_associations` VALUES (12,45,3,'2009-08-25 16:43:05','2009-08-25 16:43:05');
INSERT INTO `project_focus_area_associations` VALUES (13,43,3,'2009-08-25 16:47:02','2009-08-25 16:47:02');
INSERT INTO `project_focus_area_associations` VALUES (14,42,3,'2009-08-25 16:56:10','2009-08-25 16:56:10');
INSERT INTO `project_focus_area_associations` VALUES (15,13,3,'2009-08-25 17:42:53','2009-08-25 17:42:53');
INSERT INTO `project_focus_area_associations` VALUES (16,25,3,'2009-08-25 18:24:48','2009-08-25 18:24:48');
/*!40000 ALTER TABLE `project_focus_area_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_pictures`
--

DROP TABLE IF EXISTS `project_pictures`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `project_pictures` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `picture_file_name` varchar(255) DEFAULT NULL,
  `picture_content_type` varchar(255) DEFAULT NULL,
  `picture_file_size` varchar(255) DEFAULT NULL,
  `picture_updated_at` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `project_status_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `project_pictures`
--

LOCK TABLES `project_pictures` WRITE;
/*!40000 ALTER TABLE `project_pictures` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_pictures` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_statuses`
--

DROP TABLE IF EXISTS `project_statuses`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `project_statuses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `display_name` varchar(255) DEFAULT NULL,
  `method_name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `project_statuses`
--

LOCK TABLES `project_statuses` WRITE;
/*!40000 ALTER TABLE `project_statuses` DISABLE KEYS */;
INSERT INTO `project_statuses` VALUES (1,'Draft','draft','2009-09-13 16:25:33','2009-09-13 16:25:33');
INSERT INTO `project_statuses` VALUES (2,'New Project','new_project','2009-09-13 16:25:33','2009-09-13 16:25:33');
INSERT INTO `project_statuses` VALUES (3,'Approval Process','approval_process','2009-09-13 16:25:33','2009-09-13 16:25:33');
INSERT INTO `project_statuses` VALUES (4,'Needs More Information','needs_more_information','2009-09-13 16:25:33','2009-09-13 16:25:33');
INSERT INTO `project_statuses` VALUES (5,'Denied','denied','2009-09-13 16:25:33','2009-09-13 16:25:33');
INSERT INTO `project_statuses` VALUES (6,'Awaiting Cp','awaiting_cp','2009-09-13 16:25:33','2009-09-13 16:25:33');
INSERT INTO `project_statuses` VALUES (7,'Fundraising','fundraising','2009-09-13 16:25:33','2009-09-13 16:25:33');
INSERT INTO `project_statuses` VALUES (8,'Planning','planning','2009-09-13 16:25:33','2009-09-13 16:25:33');
INSERT INTO `project_statuses` VALUES (9,'Under Construction','under_construction','2009-09-13 16:25:33','2009-09-13 16:25:33');
INSERT INTO `project_statuses` VALUES (10,'Construction Complete','construction_complete','2009-09-13 16:25:33','2009-09-13 16:25:33');
INSERT INTO `project_statuses` VALUES (11,'Archive','archive','2009-09-13 16:25:33','2009-09-13 16:25:33');
/*!40000 ALTER TABLE `project_statuses` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_type_associations`
--

DROP TABLE IF EXISTS `project_type_associations`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `project_type_associations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_type_id` int(11) DEFAULT NULL,
  `project_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `project_type_associations`
--

LOCK TABLES `project_type_associations` WRITE;
/*!40000 ALTER TABLE `project_type_associations` DISABLE KEYS */;
INSERT INTO `project_type_associations` VALUES (1,1,1,'2009-08-09 06:08:12','2009-08-09 08:37:29');
INSERT INTO `project_type_associations` VALUES (2,16,33,'2009-08-20 17:37:55','2009-08-20 17:37:55');
INSERT INTO `project_type_associations` VALUES (3,16,31,'2009-08-25 15:12:04','2009-08-25 15:12:04');
INSERT INTO `project_type_associations` VALUES (4,16,20,'2009-08-25 15:39:43','2009-08-25 15:39:43');
INSERT INTO `project_type_associations` VALUES (5,9,4,'2009-08-25 15:55:23','2009-08-25 15:55:23');
INSERT INTO `project_type_associations` VALUES (6,16,44,'2009-08-25 16:02:56','2009-08-25 16:02:56');
INSERT INTO `project_type_associations` VALUES (7,16,32,'2009-08-25 16:13:38','2009-08-25 16:13:38');
INSERT INTO `project_type_associations` VALUES (8,16,45,'2009-08-25 16:43:14','2009-08-25 16:43:14');
INSERT INTO `project_type_associations` VALUES (9,16,43,'2009-08-25 16:47:11','2009-08-25 16:47:11');
INSERT INTO `project_type_associations` VALUES (10,16,42,'2009-08-25 17:03:06','2009-08-25 17:03:06');
INSERT INTO `project_type_associations` VALUES (11,16,25,'2009-08-25 18:24:57','2009-08-25 18:24:57');
/*!40000 ALTER TABLE `project_type_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_types`
--

DROP TABLE IF EXISTS `project_types`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `project_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `project_types`
--

LOCK TABLES `project_types` WRITE;
/*!40000 ALTER TABLE `project_types` DISABLE KEYS */;
INSERT INTO `project_types` VALUES (1,'well construction ','2009-08-09 08:37:00','2009-08-20 03:00:21');
INSERT INTO `project_types` VALUES (6,'classroom construction','2009-08-20 02:58:48','2009-08-20 02:58:48');
INSERT INTO `project_types` VALUES (7,'cafeteria equipment','2009-08-20 02:58:59','2009-08-20 03:00:32');
INSERT INTO `project_types` VALUES (8,'kitchen equipment','2009-08-20 03:00:44','2009-08-20 03:00:44');
INSERT INTO `project_types` VALUES (9,'well repair','2009-08-20 03:00:52','2009-08-20 03:00:52');
INSERT INTO `project_types` VALUES (10,'roof rainwater harvesting tanks','2009-08-20 03:01:35','2009-08-20 03:01:35');
INSERT INTO `project_types` VALUES (11,'solar lanterns','2009-08-20 03:01:44','2009-08-20 03:01:44');
INSERT INTO `project_types` VALUES (12,'biogas tanks','2009-08-20 03:01:52','2009-08-20 03:01:52');
INSERT INTO `project_types` VALUES (13,'community water tank','2009-08-20 03:02:04','2009-08-20 03:02:04');
INSERT INTO `project_types` VALUES (14,'toilets','2009-08-20 03:02:35','2009-08-20 03:02:35');
INSERT INTO `project_types` VALUES (15,'classroom equipment','2009-08-20 03:02:53','2009-08-20 03:02:53');
INSERT INTO `project_types` VALUES (16,'childcare center','2009-08-20 03:03:15','2009-08-20 03:03:15');
INSERT INTO `project_types` VALUES (17,'Hamare Bachche','2009-08-20 03:03:24','2009-08-20 03:03:24');
INSERT INTO `project_types` VALUES (18,'library construction','2009-08-20 03:03:33','2009-08-20 03:03:33');
INSERT INTO `project_types` VALUES (19,'check dam','2009-08-20 03:07:49','2009-08-20 03:07:49');
INSERT INTO `project_types` VALUES (20,'farm ponds','2009-08-20 03:08:04','2009-08-20 03:08:04');
INSERT INTO `project_types` VALUES (21,'handpump well construction','2009-08-20 03:08:46','2009-08-20 03:08:46');
INSERT INTO `project_types` VALUES (22,'handpump well repair','2009-08-20 03:08:55','2009-08-20 03:08:55');
/*!40000 ALTER TABLE `project_types` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `project_videos`
--

DROP TABLE IF EXISTS `project_videos`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `project_videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `caption` varchar(255) DEFAULT NULL,
  `video_file_name` varchar(255) DEFAULT NULL,
  `video_content_type` varchar(255) DEFAULT NULL,
  `video_file_size` varchar(255) DEFAULT NULL,
  `video_updated_at` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `project_status_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `project_videos`
--

LOCK TABLES `project_videos` WRITE;
/*!40000 ALTER TABLE `project_videos` DISABLE KEYS */;
/*!40000 ALTER TABLE `project_videos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `projects`
--

DROP TABLE IF EXISTS `projects`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ngo_id` int(11) DEFAULT NULL,
  `state_updated_at` datetime DEFAULT NULL,
  `next_step` varchar(255) DEFAULT NULL,
  `due_on` date DEFAULT NULL,
  `whats_missing` varchar(255) DEFAULT NULL,
  `why_denied` varchar(255) DEFAULT NULL,
  `project_created_at` datetime DEFAULT NULL,
  `approved_by_1well_at` datetime DEFAULT NULL,
  `sent_back_to_ngo_by_1well_at` datetime DEFAULT NULL,
  `denied_by_1well_at` datetime DEFAULT NULL,
  `permalink` varchar(255) DEFAULT NULL,
  `estimated_construction_start_date` date DEFAULT NULL,
  `actual_construction_start_date` date DEFAULT NULL,
  `estimted_construction_completed_date` date DEFAULT NULL,
  `actual_construction_completed_date` date DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `priority` varchar(255) DEFAULT NULL,
  `primary_objective` text,
  `desired_construction_start_date` date DEFAULT NULL,
  `district_coordinator` varchar(255) DEFAULT NULL,
  `community_leader` varchar(255) DEFAULT NULL,
  `total_cost_in_local_currency` int(11) DEFAULT NULL,
  `local_currency_type_id` int(11) DEFAULT NULL,
  `total_cost_in_usd` int(11) DEFAULT NULL,
  `detailed_project_budget_file_name` varchar(255) DEFAULT NULL,
  `detailed_project_budget_content_type` varchar(255) DEFAULT NULL,
  `detailed_project_budget_file_size` varchar(255) DEFAULT NULL,
  `detailed_project_budget_updated_at` varchar(255) DEFAULT NULL,
  `community_name` varchar(255) DEFAULT NULL,
  `district_name` varchar(255) DEFAULT NULL,
  `community_state` varchar(255) DEFAULT NULL,
  `country_id` int(11) DEFAULT NULL,
  `community_population` int(11) DEFAULT NULL,
  `primary_lives_impacted` int(11) DEFAULT NULL,
  `secondary_lives_impacted` int(11) DEFAULT NULL,
  `community_summary_for_website` text,
  `major_communities` text,
  `major_occupations` text,
  `average_income_per_household` int(11) DEFAULT NULL,
  `families_living_below_poverty` int(11) DEFAULT NULL,
  `brief_history_of_community` text,
  `weather` text,
  `major_issues` text,
  `summary_for_website` text,
  `justification_for_project` text,
  `what_will_be_done` text,
  `how_will_it_be_done` text,
  `environmental_sustainability` text,
  `economic_sustainability` text,
  `social_sustainability` text,
  `primary_benificiaries` text,
  `secondary_benificiaries` text,
  `primary_benefits` text,
  `productive_time_created` text,
  `jobs_created` text,
  `small_businesses_created` text,
  `income_generated` text,
  `improved_health` text,
  `other_benefits` text,
  `how_project_generates_income` text,
  `how_project_protects_families` text,
  `proposed_timeline` text,
  `agricultural_land` text,
  `animal_husbandry` text,
  `water_related_infrastructure` text,
  `sanitation` text,
  `healthcare_facilities` text,
  `transportation` text,
  `commerce` text,
  `education` text,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `cp_id` int(11) DEFAULT NULL,
  `project_status_id` int(11) DEFAULT NULL,
  `lives_impacted_range_id` int(11) DEFAULT NULL,
  `fundraising_goal_range_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `projects`
--

LOCK TABLES `projects` WRITE;
/*!40000 ALTER TABLE `projects` DISABLE KEYS */;
INSERT INTO `projects` VALUES (4,3,'2009-08-17 15:06:23','Finish construction',NULL,'','',NULL,NULL,NULL,NULL,'danajillrobin_devkiwr',NULL,NULL,NULL,NULL,'Dana, Jill & Robin\'s Well Project — Devki Village','High','Well repair',NULL,'','',NULL,NULL,0,NULL,NULL,NULL,NULL,'Devki Village','Dungarpur','Rajasthan',2,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','This project will repair and deepen the primary well in Devki, allowing the well to recharge with ground water. A deeper well will also allow for more water to be stored during the monsoon season and saved for use during the dry season.  This will give families better access to drinking and cleaning water and alleviate the strain put on existing water resources. A parapet safety barrier and a pulley system will also be constructed in order to ensure women and children are able to safely collect water from the well. \r\nTo learn more, please visit: http://1well.org/danajillrobin_devkiwr','','','','','','','Provides more than 20 families with access to a cleaner, more reliable water supply, improving village health and sanitation. Women can save about 5 hours a day of traveling long distances to obtain water, and can use the time saved earn extra income for their families.\r\nAvailable water can also be used to water crops and increase agricultural production, resulting in increased income and food security. ','','','','','','','','','','','','','','','','','','','','2009-08-17 14:16:50','2009-09-13 16:25:39',NULL,9,1,1);
INSERT INTO `projects` VALUES (5,3,'2009-08-17 14:26:04','Wire funds',NULL,'','',NULL,NULL,NULL,NULL,'josh_Waterproject',NULL,NULL,NULL,NULL,'Josh\'s Water Project — Khod & Malniyaad Village','High','',NULL,'','',NULL,NULL,0,NULL,NULL,NULL,NULL,'Khod & Malniyaad Village','Surendranagar','Gujarat',2,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','Josh has partnered with Khod Village and Malniyaad Village to complete two critical water projects to improve the health and well being of poor families in Surendranagar District. This project will fund both repair of the damaged Khod Community Water Distribution Tank and Pipelines, allowing water to flow from the tank to the taps in each household; and the construction of 20 sustainable latrines units in Malniyaad Village.\r\nJoin Josh, and provide Khod with easily accessible running water and Malniyaad with the necessary toilets and sanitation facilities to support healthy families. To learn more, please visit: http://1well.org/josh_Waterproject','','','','','','','Provides 140 households with reliable access to clean, drinking water in their homes; allows the Khod community to store and distribute 100,000 liters of water. Improved health and hygiene; increased work and school hours for Malniyaad Village','','','','','','','','','','','','','','','','','','','','2009-08-17 14:26:04','2009-09-13 16:25:39',NULL,7,1,1);
INSERT INTO `projects` VALUES (6,4,'2009-08-17 15:07:03','',NULL,'','',NULL,NULL,NULL,NULL,'subtanjalla_caekitchen/',NULL,NULL,NULL,NULL,'Mac\'s Nutrition Project — Subtanjalla District CAE','High','',NULL,'','',NULL,NULL,955,NULL,NULL,NULL,NULL,'Subtanjalla District ','','Ica Province',1,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','This project will fund equipment and materials needed to operate the Centro de Atención Externa\'s (Youth Outreach Center) kitchen, including: three-burner industrial stoves, cooking and serving utensils, cooking pots and pans, steamer, industrial sink, refrigerator, and freezer. Through better nutrition provided by the CAE, children will be better able to concentrate in school, focus while receiving psychosocial attention, and enjoy recreational activities. Nutritional services provided to children’s family members promote Coprodeli’s emphasis on community development, and draw greater commitment from beneficiaries as participants in the project.\r\nTo learn more, visit: http://1well.org/subtanjalla_caekitchen/','','','','','','','Allows 50 children, ages 4-16, to obtain nutritious, hot meals. Improves the overall health of students, and provides incentive for CAE and school attendance, allowing children to reach their potential in academic and social development.  ','','','','','','','','','','','','','','','','','','','','2009-08-17 14:31:00','2009-09-13 16:25:39',NULL,7,1,1);
INSERT INTO `projects` VALUES (7,3,'2009-08-17 14:34:08','',NULL,'','',NULL,NULL,NULL,NULL,'Akman_baby_shower',NULL,NULL,NULL,NULL,'Akman Baby Shower — Surel Village Childcare Center','High','',NULL,'','',NULL,NULL,0,NULL,NULL,NULL,NULL,'Surel Village','','Gujarat',2,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','The parents of Surel Village want to educate their children and have been trying to start a childcare center. In absence of government funds, parents are contributing 50% of the cost to operate the center, but this is very difficult given most families are only making a couple dollars a day. Matters are becoming even more difficult given the current financial meltdown.','','','','','','','Funding this project will allow 25 children to attend the childcare center, learn basic reading and math and have two hot meals a day. In addition, their mothers will have the time to earn a living wage or start a small business. This extra income will allow the family to save for the children\'s education and build a more secure future. To learn more, visit: <a href=\"http://www.1well.org/Akman_baby_shower\">Akman Baby Shower</a>.','','','','','','','','','','','','','','','','','','','','2009-08-17 14:34:08','2009-09-13 16:25:40',NULL,7,1,1);
INSERT INTO `projects` VALUES (8,4,'2009-08-17 14:37:16','',NULL,'','',NULL,NULL,NULL,NULL,'Coprodeli_VolunteerProject_Spring09/',NULL,NULL,NULL,NULL,'Coprodeli Spring 09 Group Project — Santa María Education Center','High','',NULL,'','',NULL,NULL,9,NULL,NULL,NULL,NULL,'Pachacutec','Ventanilla Province','Callao Province',1,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','This project will provide equipment for 5 recently constructed classrooms in the Santa María Education Center with tables, chairs, whiteboards and bookshelves. These classrooms are currently not being used due to the lack of equipment; this project will allow the secondary school to open and operate, enabling an additional 175 students to enroll in secondary school classes. \r\nTo learn more, visit: http://1well.org/Coprodeli_VolunteerProject_Spring09/','','','','','','','Support the Classrooms for the Santa María Project, and give the opportunity for 175 students to attend secondary school and finish their education.','','','','','','','','','','','','','','','','','','','','2009-08-17 14:37:16','2009-09-13 16:25:40',NULL,7,1,1);
INSERT INTO `projects` VALUES (9,3,'2009-08-17 14:44:02','',NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'Give the Gift of Education on Mother\'s Day','High','Our mothers gave us the greatest gift - an education. So for mother\'s day, tell your mother how much you appreciated it and donate $25 to 1Well\'s Hamare Bachche (\"Our Children\") project.\r\n\r\nHamare Bachche is a project run by the Self Employed Women\'s Association (SEWA - www.SEWA.org) that provides education and trauma counseling for children that lost one or both parents in the 2002 communal riots in Ahmedabad, India.\r\n\r\nYour $25 Mother\'s Day Gift will educate these children, and allow their mothers to work and earn an income.',NULL,'','',NULL,NULL,0,NULL,NULL,NULL,NULL,'Ahmedabad','','Gujarat',2,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','','Our mothers gave us the greatest gift - an education. So for mother\'s day, tell your mother how much you appreciated it and donate $25 to 1Well\'s Hamare Bachche (\"Our Children\") project.','','','','','','It costs $120 to cover the costs of a child\'s (ages 3 to 18) education, in addition to:\r\n? School Fees & Supplies\r\n? Trauma Assessment & Counseling\r\n? Uniforms\r\n? Room & Board (if necessary)\r\n? Health Care Services\r\n? Childcare Services for Younger Children\r\n? Vocational Guidance & Trainings\r\n? Extra-curricular Activities & Field Trips\r\n? Summer Camps, Workshops, & Picnics\r\n? Exam Preparation & TutoringHamare Bachche is a project run by the Self Employed Women\'s Association (SEWA - www.SEWA.org) that provides education and trauma counseling for children that lost one or both parents in the 2002 communal riots in Ahmedabad, India.\r\n\r\nYour $25 Mother\'s Day Gift will educate these children, and allow their mothers to work and earn an income.','','','','','','','','','','','','','','','','','','','','2009-08-17 14:44:02','2009-09-13 16:25:40',NULL,7,1,1);
INSERT INTO `projects` VALUES (10,3,'2009-08-17 14:57:04','',NULL,'','',NULL,'2008-05-14 21:56:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'','High','',NULL,'','',NULL,NULL,0,NULL,NULL,NULL,NULL,'Haji Bhachudiwandh Village ','Kutch','Gujarat',2,350,NULL,NULL,NULL,'','',NULL,NULL,'','','','Haji Bhachudiwandh is a small agricultural village that is does not have access to electricity. They need solar lanterns that help them ward off wild animals and fend off harmful insects. The lanterns also help them during their nightly activities, such as cooking and cleaning. These lanterns charge during the day and provide a sustainable source of light at night. Furthermore, SEWA has set up a lantern assembly cooperative that sells and repairs the lanterns, creating additional employment opportunities.','','','','','','','Sustainable energy source; safety; new source of livelihood','','','','','','','','','','','','','','','','','','','','2009-08-17 14:49:17','2009-09-13 16:25:40',NULL,6,1,1);
INSERT INTO `projects` VALUES (11,3,'2009-08-25 19:05:56','',NULL,'','','2008-11-11 00:00:00','2009-08-25 00:00:00',NULL,NULL,'sonalnagar',NULL,NULL,NULL,NULL,'New Trier\'s Biogas Project — Sonalnagar Village','High','New Trier High School is partnering with families in Sonalnagar to build biogas plants, small structures that mix cattle dung and water to produce clean cooking gas and organic fertilizer as a byproduct.','2009-02-01','Savitaben & Gitaben','Mataben & Babanbaben',100000,23,0,NULL,NULL,NULL,NULL,'Sonalnagar Village','Kutch District','Gujarat',2,700,25,NULL,NULL,'Darbar, Koli, Gadhvi, Harijan, Muslim','Most people in Sonalnagar are agriculture laborers and small marginal farmers that grow ground nut (peanuts), moong, bajri, guvar, sesame seeds). Many families have cattle (ox, buffalo, cows) that are used in the fields and for milk. These animals will become the main fuel source for the biogas plants. In the non-harvest season, people seek casual labor (digging ditches, road construction, etc.). Many of the women pursue alternative employment opportunities when they have time, mainly embroidery and stitching. Some have taken loans to start businesses. Metaben owns a rental business for weddings and major religious celebrations.',NULL,48,'In 1971, families from Pakistan migrated to Rajasthan, India to escape the communal violence. As refugees in Rajasthan, they received a daily stipend but were landless. Around 1988, the Indian government offered families that migrated to the Kutch District in Gujarat 10 acres of land. Many of these families, including the 5 participating in this project, moved to Kutch and founded the Sonalnagar Village.','Sonalnagar is dry, semi-arid, mainly rain fed. The village must capture as much water as possible during the rainy season so they have access to water for drinking and cleaning (done through roof rainwater harvesting) and for crop irrigation (done through farm ponds, small dams, farm bunding).Without thee facilities, the Sonalnagar is forced to spend productive time walking to collect water, or must bring in water tankers provided by the government. ','Sonalnagar lacks access to clean drinking water and sanitation which results in time lost collecting water and higher incidence of diseases like dysentery, cholera fever, etc. – which also reduce their ability to earn an income. Sonalnagar also spends valuable time collecting fuel for cooking. Some days, women have to spend 3-4 hours traveling 8 km for 10-20 kilos of wood. Farm land in Sonalnagar is poor because it lacks moisture, which reduces the number of harvests possible, the crops that can be grown and the quality and quantity of each harvest. Sonalnagar also has limited childcare facilities that limits a mothers productive time, or forces to leave her children at home unattended. \r\n\r\nMajor needs (in order of priority): accessible clean energy source; drinking water, toilet facilities, childcare center, land development','The families of Sonalnagar have asked for biogas plants – a small structure built underground on the side of a house that mixes manure from cattle – ox, buffalo, cows – with water that creates gas for cooking and heating. Chantaben, Lalaben, xben, yben and Pawanba have been selected to receive the biogas plants. They were selected based on need (productive time lost collecting wood), family size (between t4-10 people), enough cattle produce 25 kilos of manure a day (typically 4 cattle); a plot of land large enough to fit the plant, and a willingness to report on their experience and, if successful, encourage others to participate in the program.','','A family of 4-10 needs 25 kilo of manure (the amount four animals create), mixes it with 25 liters of water, which then produces 2 hours of gas in the morning and 2 hours of gas in the evening. The gas runs from the biogas unit via a rubber hose into the house where it connects to a small stove. The current practice of burning wood and kerosene is highly damaging to the lungs and is a fire hazard, especially in the houses with grass roofs.','SEWA and an engineer will visit the families to choose a site for the biogas plant. The site will prepared and the pits will be dug and then the masonry work will be completed. The entire process – site selection, material procurement, construction and testing – should take no more than a month.','Biogas prevents the destruction of the natural environment by alleviating the need to cut down trees and shrubs for wood. It reduces CO2 emissions that result from burning wood as fuel and puts to productive use the energy that already exists in animal manure. The current practice of burning wood and kerosene is highly damaging to the lungs and is a fire hazard, especially in the houses with grass roofs.','   1.  The women currently collecting wood are losing critical hours they could use to earn an income, educate and care for their children or spend in peace at an old age.\r\n   2. The biogas plant will last 20 years. The maintenance on the unit is very low. The hose will need to be test for gas leeks, but major cleaning (to remove sand, dirt and silt that has settled to the bottom of the unit) will only need to occur around year 8-10.\r\n','Continued use and a sense of ownership of the biogas plants is expected to be high since the alternative of spending hours a day collecting wood or making cow dung patties is high. The village also has requested these plants, so they have already taken the initiative. Finally, the five women who have agreed to pilot the program are highly motivated and want to demonstrate to others in the village that biogas is a better way of life than collecting wood.','Provides families with 4 hours of clean cooking gas to 6 families; reduce carbon emissions and deforestation; time saved from collecting firewood enables women to work as agricultural laborers and earn an income for their families. ','Entire village that is being introduced to a new clean energy source\r\n','4 hours (2 in the morning; 2 in the evening) of clean cooking gas','2 hours/day @ 20INR/Hr','5 jobs for women with freed up time','5 women will have the opportunity to pursue embroidery, stitching and other home based businesses','If each woman is able to work 2+ hours a day, this will help generate 60,000 INR/yr. In Sonalnagar','Burning wood causes lunch damage for the mother and children. 5 women and over 15 other family members will benefit','Women do not need to collect wood and can spend time on embroidery, stitching, and other income generating activities','Women do not need to collect wood and can spend time on embroidery, stitching, and other income generating activities','Additional income earned by women pursuing alternative forms of employment increases family income and reduces the need to seek and possibly migrate for casual labor.','   1.  Desired Project Start Date\r\n   2. Planning\r\n         1. Site identification (Day 1)\r\n         2. Engineering (Day 2)\r\n         3. Material procurement and purchase (Day 3-5)\r\n         4. Material Delivery (Day 6-10)\r\n         5. Site preparation (Day 10)\r\n         6. Digging (Day 11-13)\r\n         7. Masonry (Day14-18)\r\n         8. Finishing (Day 19)\r\n         9. Test and certification (Day 20)\r\n   3. Construction completion report (Day 30)\r\n   4. Final accounting (Day 30)\r\n   5. 1 month update (Day 60)\r\n   6. Update every 6 months (ongoing)\r\n','','','','','','','Major businesses: (soap makers, garment makers, etc.)',' 1.  Childcare centers: Government provided, but only 9AM-1:30PM\r\n 2. Schools: Government school through 7th Std.\r\n','2009-08-17 14:50:49','2009-09-13 16:25:40',NULL,8,1,1);
INSERT INTO `projects` VALUES (12,3,'2009-08-17 14:53:08','',NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'Carolyn\'s Well Project — Dungra Village','High','',NULL,'','',NULL,NULL,0,NULL,NULL,NULL,NULL,'Dungra Village','Dungarpur District','Rajasthan',2,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','The community in Dungra relies on the village well as the main source of potable water for both family as well as livestock consumption. The well, however, is in great need of repair: the broken walls, shallow bottom, and lack of pathway to the well has made obtaining water extremely hazardous. Not only is the shallow well unable to store enough water for village use, it is nearly impossible to reach the well during the monsoon season for fear of falling in. This project will deepen and repair the broken well walls as well as construct a pathway for safe passage to and from the well. Become the SVC and partner with Dungra village to ensure that the community is able to safely obtain clean drinking water for their families.','','','','','','','Provides safe access to drinking water for 40 families; increased productivity time saved from need to travel to more remote water sources in nearby villages; improved sanitation and health of the entire village','','','','','','','','','','','','','','','','','','','','2009-08-17 14:53:08','2009-09-13 16:25:40',NULL,7,1,1);
INSERT INTO `projects` VALUES (13,3,'2009-08-25 18:24:27','',NULL,'','',NULL,'2009-08-21 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'Matt & Dana\'s Wedding Registry — Sedla Village Childcare Center','High','Fund 2 years of operating cost for childcare center. The center will provide nutrition, education, and primary health care for 30 children in the surrounding communities.',NULL,'','',42300,23,NULL,'sedla_cc_project_budget.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document','40018','2009-08-21 20:30:23','Sedla Village','Surendranagar District','Gujarat',2,2122,40,NULL,NULL,'Vankar, Bhagat, Rabari, Muslim, Nat','Agriculture, Salt, small stalls',NULL,350,'The inhabitants of the village are mostly engaged in salt farming. Salt production is seasonal, as solar evaporation is the main method of extracting salt in desert regions. Thus, the salt workers live in the desert for eight months, setting up grass-roofed shacks under a scorching sun and working twelve-hour days of manual labor. Most salt workers bring their children along with them in the desert. A lot of the workers are women who have to carry their infants and toddlers along with them to their work site as there are no caretakers for them.  SEWA aims to operate a child-care center in the desert to provide basic care and education for the children of the salt workers.  \r\n\r\nThe villagers of the Sedla village are very poor. In order to start salt production in the pans the members of a cooperative can get land for salt production. The members of this village are not members of any cooperative and they therefore work as labourers on the salt pans. These members work for loading unloading and other labour work. They make their temporary shelters and live in the desert only. These labourers go and live in the desert alongwith other salt worker families from other villages.   \r\n\r\nAbout 25 of families which is almost 8.5% of the household in the village go to work in the salt pans. ','','','Many Sedla families rely on salt farming for their income, and parents are forced to take their children to work in the desert salt pans, exposing them to harmful conditions and leaving them vulnerable to disease and harmful insects.This project will create a childcare center in the desert during the salt pan season that focuses on both physical and mental development of the children, including nutrition, routine checkups, and primary education.\r\n\r\nJoin Dana & Matt and partner with Sedla village to provide the children with a safe and nurturing environment while their parents are at work. Visit <a href=\"/dana_matt_wedding\"> Matt and Dana\'s Wedding Registry </a> to learn more.','The inhabitants of the village are mostly engaged in salt farming. Salt production is seasonal, as solar evaporation is the main method of extracting salt in desert regions. Thus, the salt workers live in the desert for eight months, setting up grass-roofed shacks under a scorching sun and working twelve-hour days of manual labor. Most salt workers bring their children along with them in the desert. A lot of the workers are women who have to carry their infants and toddlers along with them to their work site as there are no caretakers for them.  SEWA aims to operate a child-care center in the desert to provide basic care and education for the children of the salt workers. ','1.	Children are provided with nutritious food and are also educated about the same.\r\n2.	Teachers of the childcare center hold regular meetings with the mothers and discuss their children’s development and give their suggestions. During this meetings the mothers are also given training so as that they know what they should do for the development of their children when they are not at the child care centers. \r\n3.	Also the mothers are given trainings on the primary health related aspects so that they could take care of their children and family during such situations\r\n4.	Children are regularly weighed and records of their growth are properly maintained.\r\n5.	The children are provided with nutritious meals and infants are given milk.\r\n6.	The childcare centers are also centers for child immunizations, antenatal and postnatal care. SEWA works closely with the government health programmes for providing these services. \r\n7.	Also if a child is sick and the immediate diagnose is required in such situation the children is referred and taken to the hospital by the child care centres workers.\r\n8.	Children in the centers are involved in pre-primary creative activities like drawing, painting and craftwork. \r\n9.	The celebration of major festival are organised at the child care centers in order that the children get knowledge and awareness for the given festival. \r\n10.	Also the children are taken for the exposure visit which helps in the overall development of the poor children of the members. \r\n','The child care centers in the District are managed by co-operatives of childcare providers, which have been formed with SEWA’s support. 45 children starting from the age of 0-6 years are served at each of this centers and focuses on the overall development of the children, including their physical and intellectual growth. Apart from this the other major activities undertaken by the childcare centers run by SEWA are as under.  ','','','    *  This would facilitate the mothers of the above children with increased income as this would allow them to work without any tension for their children. This would also help the families, communities and nation in future as this has been experienced that the children taken education from this centre are good at education and this would help in creating a bright future.\r\n    * This would also lead to more and better education of the elder children, else they are busy taking care of the younger ones\r\n','2 full-time teachers\r\n25-30 children','Families of children','From the operation of  the Childcare Programme following major impacts has been seen.  \r\n\r\n    * It is found that due to the operation of the child care centers the children of the rural poor women are protected from various diseases as they do not have to accompany their mothers at the unhealthy work-place or they are not just roaming around.\r\n    * The child care centers assure the rural poor worker that their children are taken good care and thus they could go for work which amounts to increase in income. Further to this their productivity also increases and they can also do qualitative work\r\n    * Children who have been in SEWA childcare centers value learning and education.\r\n    * The overall development of the children who attends the child care centers is much better compared to others.\r\n    * The meetings with mothers etc. educates the mothers on how to take care of the children when they are at home and also briefs them on the various aspects related to cleanliness and nutrition which further helps the development of their children\r\n    * Also the regular training to the teachers facilitates in the betterment of overall child development and child education\r\n','','2','','','','    *  Permanent jobs created : 3 teachers\r\n    * Productive Time Created: This would facilitate the beneficiaries (parents of 40 children with tension free and more productive working hours ultimately leading hem towards sustainable livelihood\r\n    * Children with childcare/education: 40 children\r\n    * Overall Child development : 40 children\r\n    * More and better education to elder children in family\r\n','','','','Main agricultural crops:  Kharif – Bajri, Jowar, Moong, Math, Sesame,\r\n\r\nRabi – Cumin, Cotton','','','','','','','School:    Primary school up to 7th std.\r\n\r\nChild-care centre:   1','2009-08-17 14:55:45','2009-09-13 16:25:40',NULL,10,1,1);
INSERT INTO `projects` VALUES (14,4,'2009-08-17 14:59:31','',NULL,'','',NULL,'2009-02-20 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'','High','',NULL,'','',NULL,NULL,1000,NULL,NULL,NULL,NULL,'Subtanjalla','Ica Province','Ica Province',1,16,50,NULL,NULL,'','',NULL,NULL,'','','','Coprodeli has built a Centro de Atención Externa (Youth Outreach Center) to provide dignified housing and access to education, health care and child development services to earthquake victims of Subtanjalla living in extreme poverty. This project will fund a classroom for the CAE, including furniture and media equipment, to hold parent workshops, group sessions for children and recreation activities. The classroom will create a comfortable and safe area for CAE program activities to be carried out effectively in an environment that promotes beneficiary participation and active involvement.','','','','','','','Provides 50 at-risk children with space for tutoring, studying, in addition to parent and community development workshops.','','','','','','','','','','','','','','','','','','','','2009-08-17 14:56:38','2009-09-13 16:25:40',NULL,6,1,1);
INSERT INTO `projects` VALUES (15,3,'2009-08-17 15:44:25','',NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'LTHS\'s Hamare Bachche Project — Ahmedabad City','High','',NULL,'','',NULL,NULL,0,NULL,NULL,NULL,NULL,'Ahmedabad','','Gujarat',2,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','In 2002, massive riots resulted in the deaths of over 1,000 people in Gujarat, India, leaving many poor widows and orphans to gather the threads of their lives. SEWA started the Hamare Bachche (\"Our Children\") program to fund the education and counseling for children who lost one or both parents in the riots. \r\nJoin the students of Lyons Township High School, and partner with the Ahmedabad by providing child victims of the 2002 riots with the opportunity to advance to high school and beyond. To learn more, visit: http://1well.org/lt_hbahmedabad/','','','','','','','Provides school fees, school supplies, healthcare, and trauma counseling for 20 children affected by communal violence. Allows students to advance to secondary school and acquire skills to succeed in life. ','','','','','','','','','','','','','','','','','','','','2009-08-17 14:57:46','2009-09-13 16:25:40',NULL,7,1,1);
INSERT INTO `projects` VALUES (16,3,'2009-08-17 15:02:14','',NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'Osyrusfest Well Project — Varkhadiya Village','High','',NULL,'','',NULL,NULL,0,NULL,NULL,NULL,NULL,'Varkhadiya Village','Mehsana District','Gujarat',2,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','Varkhadiya suffers from a shortage of drinking water, and its wells have broken walls and no safety barriers, making it a hazard for women who must lean into the well with a pail and rope to collect water. This project will repair and deepen 2 wells in Varkhadiya, giving families better access to drinking water and alleviating the strain put on existing water resources. A parapet safety barrier and a pulley system will also be constructed in order to ensure women and children are able to safely collect water from the well. A deeper well will allow for more water to be stored during the monsoon season and saved for use during the dry season.\r\nJoin Osyrusfest and provide Varkhadiya with the water infrastructure it needs to support a healthy community. To learn more, visit: http://1well.org/osyrusfest/','','','','','','','Provides 500 households with access to clean water. Women will save time from traveling long distances to obtain water, and use time saved to earn extra income by pursuing soap and incense-making work.','','','','','','','','','','','','','','','','','','','','2009-08-17 15:02:14','2009-09-13 16:25:40',NULL,7,1,1);
INSERT INTO `projects` VALUES (17,3,'2009-08-17 15:04:20','',NULL,'','','2008-10-19 00:00:00',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'','High','',NULL,'','',NULL,NULL,5000,NULL,NULL,NULL,NULL,'Ahmedabad','','Gujarat',2,NULL,60,NULL,NULL,'','',NULL,NULL,'','','','In 2002, massive riots resulted in the deaths of over 1,000 people in Gujarat, India, leaving many poor widows and orphans to gather the threads of their lives. SEWA started the Hamare Bachche (\"Our Children\") program to fund the education and counseling for children who lost one or both parents in the riots. In addition to tuition, the project provides students with room and board, counseling, school supplies, and healthcare. Become the Citizen Philanthropist for this project and partner with Ahmedabad by providing their children with the opportunity to advance to high school and vocational training.','','','','','','','Provides healthcare, trauma counseling and school fees for the continued education of 60 children affected by communal violence. This allows them to advance to secondary school and acquire skills to succeed in life. ','','','','','','','','','','','','','','','','','','','','2009-08-17 15:03:06','2009-09-13 16:25:40',NULL,6,1,1);
INSERT INTO `projects` VALUES (18,3,'2009-08-17 15:09:54','',NULL,'','',NULL,'2008-05-14 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'','High','',NULL,'','',NULL,NULL,6800,NULL,NULL,NULL,NULL,'Zejari','Surendranagar','Gujarat',2,850,NULL,NULL,NULL,'','',NULL,NULL,'','','','Zejari Village is a poor village in the interior the Surendranagar District in Gujarat, India. The village relies on rain-fed agriculture and struggles to maintain the quality of its cultivatable land. In order to improve the quality of the land and to increase the quality and quantity of their crop production, farmers need to deep plough the land to bringing richer, better soil to the top. This simple exercise, along with sustainable farming techniques, will increasing crop yields by 2-3 times. Become the Citizen Philanthropist for this project and help Zajari Village access a tractor that will make the deep ploughing of the land possible.','','','','','','','Increasing crop yields by 2-3 times; increase family income. ','','','','','','','','','','','','','','','','','','','','2009-08-17 15:09:54','2009-09-13 16:25:40',NULL,6,1,2);
INSERT INTO `projects` VALUES (19,3,'2009-08-17 15:44:01','',NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'Tina\'s Well Project — Nokna Village','High','',NULL,'','',NULL,NULL,0,NULL,NULL,NULL,NULL,'Nokna Village','Dungarpur District','Rajasthan',2,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','This project will repair and deepen the primary well in Nokna by 20 feet, and provide a parapet safety barrier and a pulley system to ensure women and children are able to safely collect water from the well. A deeper well will allow for more water to be stored during the monsoon season and saved for use during the dry season. In addition, this well repair and deepening project will supply water for bathing and cleaning as well as drinking water for cattle and other livestock.<br>\r\nLearn more: http://1well.org/tsac_noknawell/','','','','','','','60 families will have access to a cleaner, more reliable water supply; women can save 4-6 hours a day of traveling long distances to obtain water, and can use the time saved earn extra income for their families.','','','','','','','','','','','','','','','','','','','','2009-08-17 15:13:57','2009-09-13 16:25:40',NULL,7,1,1);
INSERT INTO `projects` VALUES (20,3,'2009-08-25 15:39:54','',NULL,'','','2008-05-12 00:00:00','2009-08-21 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'Bilodra Childcare Center','High','Fund operating cost for childcare center in Bilodra Village.  The center will provide nutrition, education, and primary healthcare for 35 children in the surrounding communities',NULL,'Rehana Riyawala / Alka Shah','Anandiben ',254150,23,4600,'bilodra_cc_project_budget.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document','11155','2009-08-21 17:10:33','Bilodra','Anand','Gujarat',2,7365,35,NULL,NULL,'Patel, Vankar, Bharwad, Bajaniya','Agriculture',NULL,NULL,'The village is at the distance of 7 kms. from Nadiyad block and 27 kms. from Anand. The majority of the village community are agriculture labourers and vegetable growers. The major crops include wheat, bajri and vegetables. Given the majority of the poor communities being agriculture workers and lack of child care facilities they have to take their children along with them in the fields, which hampers their productivity as well as the health and overall development of the children.\r\n\r\nPresently SEWA has membership of 400 in this village. In this village SEWA started organising in the year 1996. Apart from organising the major activities facilitated by SEWA in this village includes health care, child care, micro finance, jeevan shala (life school) and trainings & capacity building of members.  ','','','SEWA has operated a childcare center in Bilodra since 1999. It currently takes care of 30 children between the ages of 0-6 years old, but the center needs repair and renovation work. The center focuses on the overall development of the children, including their physical and intellectual growth. The center lacks funds and needs a partner that will help them provide the children with a healthy, encouraging learning environment, nutritious meals, education field trips, and immunization and primary care. The center will also help counsel parents on how to foster a learning environment at home. Become the Citizen Philanthropist for this project and partner with Bilodra village to create a positive educational environment for their children.','At SEWA it is well understood that without childcare, including child development, its goal of full employment and self-reliance will remain unfulfilled. Working mothers cannot take their children to their workplaces without jeopardizing their own work efficiency and their children’s safety. SEWA believes that women’s struggle to emerge out of poverty through the quest for work and income security, must be supported by quality childcare.  SEWA’s childcare programme emerged in mid 1970 from the needs expressed by its members.  \r\n\r\nAlso given that the poor members of this Village have to work hard in fields in any weather / atmosphere and without any childcare facilities prevalent this poor members have to take their childrens along with them in the unhealthy working environment which not only affect the health and development of the children but also jeopardize their own work efficiency and their children’s safety. Their education too suffered. ','1.	Children are provided with nutritious food and are also educated about the same.\r\n2.	Teachers of the childcare center hold regular meetings with the mothers and discuss their children’s development and give their suggestions. During this meetings the mothers are also given training so as that they know what they should do for the development of their children when they are not at the child care centers. \r\n3.	Also the mothers are given trainings on the primary health related aspects so that they could take care of their children and family during such situations\r\n4.	Children are regularly weighed and records of their growth are properly maintained.\r\n5.	The children are provided with nutritious meals and infants are given milk.\r\n6.	The childcare centers are also centers for child immunizations, antenatal and postnatal care. SEWA works closely with the government health programmes for providing these services. \r\n7.	Also if a child is sick and the immediate diagnose is required in such situation the children is referred and taken to the hospital by the child care centres workers.\r\n8.	Children in the centers are involved in pre-primary creative activities like drawing, painting and craftwork. \r\n9.	The celebration of major festival are organised at the child care centers in order that the children get knowledge and awareness for the given festival. \r\n10.	Also the children are taken for the exposure visit which helps in the overall development of the poor children of the members. \r\n\r\nThis child care centers play very important role in the life of poor workers from the informal economy as this are the centers of their own kind i.e. (a) it serves the children for the whole day that to as per the working hours of the poor women members from the informal economy and (b) cater services to the children as small as 15 days. The centers support infants i.e. 0-3 years of age, with milk.  ','Thus based on the members demand SEWA started the Child Care Centre in the village in the year 1999. Presently 30 children of this poor community members are being taken care at the Centre. The Child care centre in this village is been operated in the land given by the village gram panchayat. The Centre needs certain repairing and renovation work. ','','','This would facilitate the mothers of the above children with increased income as this would allow them to work without any tension for their children. This would also help the families, communities and nation in future as this has been experienced that the children taken education from this centre are good at education and this would help in creating a bright future.\r\n\r\nThis would also lead to more and better education of the elder children, else they are busy taking care of the younger ones\r\n','2 full-time teaching jobs\r\n35 healthier children','This would help mothers generate income by freeing the time that would otherwise be spent on overseeing the children.\r\n\r\nThis would also allow older children to focus on education by freeing time that would otherwise be spent on taking care of their little brothers and sisters\r\n','From the work experience of three decades in the Childcare Programme following major impacts has been seen.  \r\n\r\n- It is found that due to the operation of the child care centers the children of the rural poor women are protected from various diseases as they do not have to accompany their mothers at the unhealthy work-place or they are not just roaming around.\r\n-The child care centers assure the rural poor worker that their children are taken good care and thus they could go for work which amounts to increase in income. Further to this their productivity also increases and they can also do qualitative work\r\n-Children who have been in SEWA childcare centers value learning and education.\r\n-The overall development of the children who attends the child care centers is much better compared to others.\r\n-The meetings with mothers etc. educates the mothers on how to take care of the children when they are at home and also briefs them on the various aspects related to cleanliness and nutrition which further helps the development of their children\r\n-Also the regular training to the teachers facilitates in the betterment of overall child development and child education\r\n','','2','0','','','','','','The funds will support the operation of this childcare center for 2 years.  The center is maintained and operated continuously by SEWA','Available agricultural Land: 464 Hectare \r\nWith irrigation facilities: 280\r\nWithout irrigation facilities:  184 hectare\r\nFutile land: 184 Hectare\r\nType of Soil: black, clay and sandy \r\nAnimal Husbandry\r\nCows: 500\r\nBuffalo: 300\r\nBullock: 12\r\n','Available agricultural Land: 464 Hectare \r\nWith irrigation facilities: 280\r\nWithout irrigation facilities:  184 hectare\r\nFutile land: 184 Hectare\r\nType of Soil: black, clay and sandy \r\nAnimal Husbandry\r\nCows: 500\r\nBuffalo: 300\r\nBullock: 12\r\no	Sheep : 100\r\no	Goat : 100\r\n','Ponds: 4\r\nWell: 2\r\nTube well : -\r\nJuth Yojana: -\r\nRoof Rain Water Harvesting Tanks: 1 \r\n','Toilets: no\r\nWashing facilities: no\r\n','Primary Health Care Centre: No\r\nGovernment Clinic: 1 but is not opened\r\nDistance to primary health care facility : NA.\r\nDistance to large hospital : 10 kms. \r\n','Distance to nearest town : 7 kms\r\nDistance to public bus stop : 0.25 kms\r\nCycles: 3000\r\nScooter / bike : 2500\r\nTractor: 800\r\nCarts: -\r\n','Major businesses: Agriculture and animal husbandry \r\nGrocery Shop: 10\r\nOther businesses/entrepreneurs: - \r\n','Government Operated Child care: Yes but operates only from 11 am to 2 pm. Focus on education only not nutrition.\r\nSchool: 4 primary school and 1 high school\r\n','2009-08-17 15:14:14','2009-09-13 16:25:40',NULL,6,1,1);
INSERT INTO `projects` VALUES (21,3,'2009-08-17 15:24:30','',NULL,'','',NULL,'2008-10-20 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'','High','',NULL,'','',NULL,NULL,3700,NULL,NULL,NULL,NULL,'Bandhwad','Patan','Gujarat',2,NULL,1000,NULL,NULL,'','',NULL,NULL,'','','','Heath and sanitation has become an issue for the village of Bandhwad, which currently lacks toilet facilities. Community members are forced to walk to the village outskirts to relieve themselves in an effort avoid contaminating water sources. This lack of basic sanitation has dramatically increased the infection rate of disease throughout the village, in addition to affecting the productivity time and schooling of both adults and children of the community. This project will create 8 toilet facilities throughout Bandhwad, giving every household access to proper sanitation facilities. Become the Citizen Philanthropist for this project, and partner with Bandhwad to improve the health, sanitation, and livelihood of the villagers. ','','','','','','','Improved health for 1,000 families in Bandhwad; increased work and school hours','','','','','','','','','','','','','','','','','','','','2009-08-17 15:23:31','2009-09-13 16:25:40',NULL,6,2,1);
INSERT INTO `projects` VALUES (22,3,'2009-08-17 15:45:11','',NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'Ethan and Maha\'s Hamare Bachche Project — Ahmedabad City','High','',NULL,'','',NULL,NULL,240,NULL,NULL,NULL,NULL,'Ahmedabad','','Gujarat',2,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','In 2002, communal riots in Gujarat, India left more than 900 women widowed and over 600 children orphaned. This project will support the SEWA Hamare Bachche (\"Our Children\") program in Ahmedabad for the 2009-2010 school year. Funds raised will provide children who lost one or both parents in the riots with healthcare, nutritious food, education and trauma counseling. \r\nJoin Ethan and Maha, and partner with the Hamare Bachche Ahmedabad program to allow students to finish their education. To learn more, visit: http://1well.org/ethanmaha_hbahmedabad/','','','','','','','Provides primary healthcare, trauma counseling, school supplies, and education fees for the continued education of 2 children affected by communal violence. This allows them to advance to secondary school and acquire skills to succeed in life. ','','','','','','','','','','','','','','','','','','','','2009-08-17 15:25:28','2009-09-13 16:25:40',NULL,9,1,1);
INSERT INTO `projects` VALUES (23,3,'2009-08-17 15:27:04','',NULL,'','','2008-10-20 00:00:00',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'','High','',NULL,'','',NULL,NULL,5300,NULL,NULL,NULL,NULL,'Varkhadiya','Mehsana ','Gujarta',2,3000,NULL,NULL,NULL,'','',NULL,NULL,'','','','Varkhadiya suffers from a shortage of drinking water as the wells in Varkhadiya are in a state of disrepair and the little water available is contaminated with excess fluoride, causing joint problems for the villagers. Furthermore, clean water is needed for the manufacture of detergent and incense sticks to supplement the income of the poor women in the village. \r\nThis project will construct a roof rainwater harvesting system with an accompanying hand-pump, which allows villagers to capture the water during the monsoon season and channel it into storage tanks for use during the dry season. Become the Citizen Philanthropist for this project, and partner with Varkhadiya to provide water that will help improve the health, sanitation, and livelihood of the villagers. ','','','','','','','Provides potable water for 550 families, improving the health and sanitation of the village; allows village women to take on detergent and incense making activities to generate income for their families','','','','','','','','','','','','','','','','','','','','2009-08-17 15:26:53','2009-09-13 16:25:40',NULL,6,1,2);
INSERT INTO `projects` VALUES (24,3,'2009-08-17 15:45:36','',NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'Ed\'s Hamare Bachche Project — Mehsana District','High','',NULL,'','',NULL,NULL,0,NULL,NULL,NULL,NULL,'Villages in Mehsana District','Mehsana District','',2,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','In 2002, massive riots resulted in the deaths of over 1,000 people in Gujarat, India, leaving many poor widows and orphans to gather the threads of their lives. SEWA started the Hamare Bachche (\"Our Children\") program in several villages in the region which funded the education and counseling of children who lost one or both parents in the riots. This project will support the Hamare Bachche Mehsana program for the 2009-2010 school year, and allow Hamare Bachche students who are currently out of school to return and finish their education. \r\nJoin Ed, and partner with the Mehsana District by providing child victims of the 2002 riots with the opportunity to advance to high school and beyond. To learn more, visit: http://1well.org/ed_hbmehsana','','','','','','','Provides healthcare, counseling, tuition fees, and school supplies for 11 children affected by communal violence. This allows them to advance to secondary school and acquire skills to succeed in life. ','','','','','','','','','','','','','','','','','','','','2009-08-17 15:27:44','2009-09-13 16:25:40',NULL,7,1,1);
INSERT INTO `projects` VALUES (25,3,'2009-08-25 18:35:14','',NULL,'','','2008-05-12 00:00:00','2009-08-21 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'SEVA DC\'s Education Project — Vera Childcare Center','High','Fund 2 years of operating cost for childcare center. The center will provide nutrition, education, and primary health care for 30 children in the surrounding communities.',NULL,'Rehana Riyawala / Alka Shah','Nandaben ',226000,23,NULL,'vera_cc_project_budget.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document','29264','2009-08-21 19:23:40','Vera Village','Anand District','Gujarat',2,5638,25,NULL,NULL,'Patel, Darbar, Rohit, Harijan, Vankar, Talpada, Muslim','Agriculture and tobacco workers, animal husbandry, and miscellaneous workers',NULL,NULL,'The village is at the distance of 17 kms. from Anand. The majority of the village community are agriculture labourers, majority of them being tobacco agriculture workers. Given the employment in the tobacco fields the major issue in this village was the occupational health hazards prevailing among the poor tobacco agriculture workers and their children and lack of child care facilities for the children of these workers.\r\n\r\nPresently SEWA has membership of 200 in this village. In this village SEWA started organising in 1994. Apart from organising the major activities facilitated by SEWA in this village includes health care, child care, micro finance and trainings & capacity building of members. ','','','SEWA\'s current childcare facility in Vera village is in great need of repair and renovation. The center lacks funds and needs a partner that will help them provide 30 children with a healthy, encouraging learning environment, nutritious meals, education field trips, and immunization and primary care. The center focuses on the overall development of the children, including their physical and intellectual growth. In addition to those direct needs, the center will also help council parents on fostering a healthy learning environment at home. Invest in this project, and join SEVA DC to create a positive educational environment for the children in Vera. \r\nVisit http://www.1well.org/vera to learn more.','At SEWA it is well understood that without childcare, including child development, its goal of full employment and self-reliance will remain unfulfilled. Working mothers cannot take their children to their workplaces without jeopardizing their own work efficiency and their children’s safety. SEWA believes that women’s struggle to emerge out of poverty through the quest for work and income security, must be supported by quality childcare.  SEWA’s childcare programme emerged in mid 1970 from the needs expressed by its members.  \r\n\r\nAlso the poor workers in this Village were over exposed to nicotine in the tobacco fields and thus suffered from various diesease like tubercolouses, Asthama etc.  Same was the case with their children as their does not exist any facility were their children could be taken care and hence, workers had no option but to take their children along with them to tobacco fields and thus were exposed to the nicotine environment.  Their education too suffered.\r\n\r\nThus based on the members demand SEWA started the Child Care Centre in the village in the year 1993. Presently 30 children of this poor community members are being taken care at the Centre. \r\n','   1.  Children are provided with nutritious food and are also educated about the same.\r\n   2. Teachers of the childcare center hold regular meetings with the mothers and discuss their children’s development and give their suggestions. During this meetings the mothers are also given training so as that they know what they should do for the development of their children when they are not at the child care centers.\r\n   3. Also the mothers are given trainings on the primary health related aspects so that they could take care of their children and family during such situations\r\n   4. Children are regularly weighed and records of their growth are properly maintained.\r\n   5. The children are provided with nutritious meals and infants are given milk.\r\n   6. The childcare centers are also centers for child immunizations, antenatal and postnatal care. SEWA works closely with the government health programmes for providing these services.\r\n   7. Also if a child is sick and the immediate diagnose is required in such situation the children is referred and taken to the hospital by the child care centres workers.\r\n   8. Children in the centers are involved in pre-primary creative activities like drawing, painting and craftwork.\r\n   9. The celebration of major festival are organised at the child care centers in order that the children get knowledge and awareness for the given festival.\r\n  10. Also the children are taken for the exposure visit which helps in the overall development of the poor children of the members.\r\n\r\n \r\nThis child care centers play very important role in the life of rural poor women workers as this are the centers of their own kind i.e. (a) it serves the children for the whole day that to as per the working hours of the poor women members from the informal economy and (b) cater services to the children as small as 15 days. The centers support infants i.e. 0-3 years of age, with milk.  ','These center is managed by co-operatives of childcare providers, which have been formed with SEWA’s support. 30 - 35 children starting from the age of 0-6 years are served at each of this centers and focuses on the overall development of the children, including their physical and intellectual growth. Apart from this the other major activities undertaken by the childcare centers run by SEWA are as under.  ','','','    *  This would facilitate the mothers of the above children with increased income as this would allow them to work without any tension for their children. This would also help the families, communities and nation in future as this has been experienced that the children taken education from this centre are good at education and this would help in creating a bright future.\r\n    * This would also lead to more and better education of the elder children, else they are busy taking care of the younger ones\r\n','3 full-time teaching jobs\r\n25-30 children','Families of the children','From the operation of  the Childcare Programme following major impacts has been seen.  \r\n\r\n    * It is found that due to the operation of the child care centers the children of the rural poor women are protected from various diseases as they do not have to accompany their mothers at the unhealthy work-place or they are not just roaming around.\r\n    * The child care centers assure the rural poor workers that their children are taken good care and thus they could go for work which amounts to increase in income. Further to this their productivity also increases and they can also do qualitative work\r\n    * Children who have been in SEWA childcare centers value learning and education.\r\n    * The overall development of the children who attends the child care centers is much better compared to others.\r\n    * The meetings with mothers etc. educates the mothers on how to take care of the children when they are at home and also briefs them on the various aspects related to cleanliness and nutrition which further helps the development of their children\r\n    * Also the regular training to the teachers facilitates in the betterment of overall child development and child education\r\n','','2','','','','    *  Permanent jobs created : 2 teachers\r\n    * Productive Time Created: This would facilitate the beneficiaries (parents of 25 - 30 children with tension free and more productive working hours ultimately leading hem towards sustainable livelihood\r\n    * Children with childcare/education: 25 - 30 children\r\n    * Overall Child development : 25 - 30 children\r\n    * More and better education to elder children of the family\r\n','','','The funds will support the operation of this child care center for 2 years','Available agricultural Land: 733 hectare\r\nWith irrigation facilities: 733 hectares\r\nWithout irrigation facilities:  -\r\nFutile land: - \r\nType of Soil: Goralu, Kyari and Retal \r\n','Cows: 96\r\nBuffalo: 378\r\nBullock: 10\r\nSheep : 100\r\n','Ponds: 2\r\nWell: 6\r\nBore well : 6\r\nJuth Yojana: -\r\nRoof Rain Water Harvesting Tanks: 3\r\n','Toilets: yes\r\nWashing facilities: yes\r\n','Primary Health Care Centre: 1\r\nGovernment Clinic: 1\r\nDistance to primary health care facility : 1 km\r\nDistance to large hospital : 3 kms\r\n','Distance to nearest town : 3 kms\r\nDistance to public bus stop : 1 km\r\nCycles: 200\r\nScooter : 50\r\nTractor: 14\r\nCarts: 8\r\n','Major businesses: Agriculture and Tobacco Workers\r\nGrocery Shop: 50\r\nOther businesses/entrepreneurs: Animal Husbandry\r\n','Government Operated Child care : Yes but operates only from 11 am to 2 pm but is not as per the working hours of the parents and is just taking care the aspects of education and nutrition is not taken care properly\r\n\r\nSchool: 1 nursery, 3 primary, 1 highschool and 1 higher secondary  \r\n','2009-08-17 15:29:32','2009-09-13 16:25:40',NULL,7,1,1);
INSERT INTO `projects` VALUES (26,3,'2009-08-17 15:31:07','',NULL,'','','2008-05-14 00:00:00',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'','High','',NULL,'','',NULL,NULL,8700,NULL,NULL,NULL,NULL,'Kankavati ','Surendranagar','Gujarat',2,5000,NULL,NULL,NULL,'','',NULL,NULL,'','','','There are no toilets in Kankavati. Villagers have to walk long distances to go to the toilet. Women are most affected as they are often forced to relieve themselves in public view, putting them in a humiliating and stressful situation. These unsanitary conditions increase the spread of disease. The absence of toilets in schools force children to leave their classes and walk long distances to relieve themselves, hindering their education. Become the Citizen Philanthropist for this project and partner with Kankavati to provide toilet facilities that will help improve the health, sanitation, and livelihood of the villagers.','','','','','','','Improved health; increased work and school hours.','','','','','','','','','','','','','','','','','','','','2009-08-17 15:31:07','2009-09-13 16:25:40',NULL,6,1,2);
INSERT INTO `projects` VALUES (27,3,'2009-08-17 15:33:45','',NULL,'','',NULL,'2008-05-14 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'','High','',NULL,'','',NULL,NULL,6500,NULL,NULL,NULL,NULL,'Degam','Surendranagar','Gujarat',2,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','Degam relies on rain-fed agriculture and struggles to maintain the quality of its cultivatable land. In order to improve the quality of the land and to increase the quality and quantity of their crop production, farmers need to deep plough the land to bringing richer, better soil to the top. This simple exercise, along with sustainable farming techniques, will increasing crop yields by 2-3 times. Become the Citizen Philanthropist for this project and help Degam Village access a tractor that will make the deep ploughing of the land possible.','','','','','','','Increasing crop yields by 2-3 times; increase family income.','','','','','','','','','','','','','','','','','','','','2009-08-17 15:33:45','2009-09-13 16:25:40',NULL,6,1,2);
INSERT INTO `projects` VALUES (28,3,'2009-08-17 15:37:11','',NULL,'','',NULL,'2008-05-14 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'','High','',NULL,'','',NULL,NULL,6300,NULL,NULL,NULL,NULL,'Mayapur','Surendranagar ','Gujarat',2,450,NULL,NULL,NULL,'','',NULL,NULL,'','','','Mayapur farmers earn their livelihoods on small plots ranging from two to five acres of land. Their livelihood relies on the ability to improve the quality of the soil. These farmers need capital to undertake land development activities - filling mud, soil, and sand into the land - that will increase the quality and quantity of crops. Mud filling improves the quality and fertility of the land. Sand filling helps maintain the land’s moisture level while reducing the soil’s salinity. After such activities, productivity increases 15% to 20%.','','','','','','','Crop productivity increase of 15% to 20%','','','','','','','','','','','','','','','','','','','','2009-08-17 15:37:11','2009-09-13 16:25:40',NULL,6,1,2);
INSERT INTO `projects` VALUES (29,4,'2009-08-17 15:43:01','',NULL,'','',NULL,'2009-03-23 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'','High','',NULL,'','',NULL,NULL,5500,NULL,NULL,NULL,NULL,'Subtanjalla','Ica','',1,16,NULL,NULL,NULL,'','',NULL,NULL,'','','','Coprodeli has built a Youth Outreach Center (Centro de Atención Externa, CAE) to provide dignified housing and access to education, health care and child development services to earthquake victims of Subtanjalla living in extreme poverty. The CAE’s focus includes psychosocial and medical care, nutrition, and education support, and an emphasis on identifying children in situations of high risk. The CAE currently operates in a temporary structure with particle board walls, thatched roof, concrete floor, no running water, and limited electricity, among others.\r\nThis project will fund the construction and supplies for a cafeteria to better serve the nutritional needs of CAE children and their families.','','','','','','','Allows 50 children, ages 4-16, to obtain nutritious, hot meals. Improves the overall health of students, and provides incentive for CAE and school attendance, allowing children to reach their potential in academic and social development.  ','','','','','','','','','','','','','','','','','','','','2009-08-17 15:40:29','2009-09-13 16:25:40',NULL,6,1,2);
INSERT INTO `projects` VALUES (30,3,'2009-08-17 15:45:54','',NULL,'','',NULL,'2008-05-14 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'','High','',NULL,'','',NULL,NULL,7900,NULL,NULL,NULL,NULL,'Zadiyana ','Surendranagar ','Gujarat',2,2000,NULL,NULL,NULL,'','',NULL,NULL,'','','','Zadiyana borders the desert and access to water is a major problem. The village is dependent upon seasonal rain fall, and water tables are falling. As water becomes more and more scarce, communities are beginning to migrate, leaving those left behind with fewer and fewer resources. Roof rainwater harvesting allows villagers to capture the water during the rainy season and channel it into storage tanks for use during the dry season. This project will allow for the storage of 5,000 to 10,000 liters of water. Become the Citizen Philanthropist for this project and partner with Zadiyana to provide water that will help improve the health, sanitation, and livelihood of the villagers.','','','','','','','Increased source of drinking water; improved sanitation; improved health; reduce the need to migrate','','','','','','','','','','','','','','','','','','','','2009-08-17 15:45:54','2009-09-13 16:25:40',NULL,6,1,2);
INSERT INTO `projects` VALUES (31,3,'2009-08-25 15:27:33','',NULL,'','','2009-01-22 00:00:00','2009-08-21 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'Ed\'s Hamare Bachche Project — Anand & Kheda Districts','High','Provide education for the 32 children (orphans and single-parent families) affected by the communal riots in Gujarat in 2002. ',NULL,'Rehanaben / Alkaben',' Jasintaben',88650,23,1799,NULL,NULL,NULL,NULL,'Villages in Anand & Kheda','Anand & Kheda','Gujarat',2,NULL,32,NULL,NULL,'','',NULL,NULL,'In 2002, a train in the city of Godhra in Gujarat, India was set ablaze by a mob, sparking a massive riot that resulted in the deaths of over a 1,000 people. The dead were mostly several male breadwinners of these poor communities. According to official accounts, 900 women were widowed and over 600 children orphaned. Many of the children were severely shocked by the brutality of the Gujarat riots, and often witnessed their parents being burnt alive by mobs. The widows and children of these victims not only suffered deep psychological trauma; they also lost their means of livelihood and lack the education and support to restart their lives. \r\n\r\nMany of these widows were fully supported by their husbands and lived in seclusion. After the death of their husbands, they were bound by custom to stay at home and mourn. In some cases, their inactivity fueled their severe depression. As a labor union, SEWA recognizes the value of work not only for income but also as a confidence booster. Some of the widows began proactively seeking employment, realizing that the compensation money from the government would not last and also that they needed a way of interacting with others.\r\n\r\nThis program will cover children from 16 villages in this district. This includes Mogar, Mehmdabad, Ankleshwar, Surat, Khambhat, Borsad, Nadiad, Vasad, Kapadvanj, Chikhodra, Sanghana, Sojitra, Bhalej, Thamna and Mehlaj. There are childcare centers and a primary school in these villages. However for high school, the children have to go to nearby villages. These villages have a primary health care centre. The main mode of transportation is by auto rickshaws and buses. These children live in the outskirts of the villages. There is a bridge that has been built for commuting. The children use this bridge to go to school and it takes them 20-30 minutes. The main forms of employment in these villages are agriculture, casual labor, cattle rearing, household work and grocery stores.','','These children are provided with fees, books, stationery and other sundries. However, due to the lack of funds, this year we have been unable to pay fees and purchase study materials for the children. As a result, it has become very difficult for the children to further their studies. So, some children have discontinued their studies.\r\n\r\nThus the major need is for funds to pay their school fees and provide them with the material in order to enable them to continue their studies. ','In 2002, massive riots resulted in the deaths of over 1,000 people in Gujarat, India, leaving many poor widows and orphans to gather the threads of their lives. SEWA started the Hamare Bachche (\"Our Children\") program aimed at supporting education and counseling of children who lost one or both parents in the riots. This project will support the Hamare Bachche Anand & Kheda program for the 2009-2010 school year, and allow Hamare Bachche students to finish their education.\r\nJoin Ed, and partner with the Anand & Kheda Districts by providing child victims of the 2002 riots with the opportunity to advance to high school and beyond. To Learn more, visit: http://1well.org/ed_hbanandkheda','      Therefore, the primary aim of the rehabilitation of the children after the horrible events of 2002 is to divert their minds from the tragic incident. As education should be the main priority for any child, it is crucial for the children to go back to school and attend it regularly. A pilot program was started by SEWA to fund and encourage 32 children to continue their education. However, the children were afraid to leave their homes as they were still haunted by the past. Their mothers were also reluctant to send their children to school out of fear. SEWA initiated a faith-building process with its grassroots researchers acting as hand-holders. The SEWA team frequently visited and spent more time with the children and their mothers giving solace and encouragement \r\n\r\n      The psychological trauma faced by the children requires special care and attention. Regular meetings with teachers and guardians are held to monitor the children’s well-being and education; teachers were instructed to deal these children with patience and utmost care. Special tutoring and test prep are also given to needy Hamare Bachche students to inspire confidence and improve performance. Beginning with admission in the schools and hostels, their every need as students was taken care of by SEWA.','The Self Employed Women’s Assocation (SEWA) started the Hamare Bachche (“Our Children”) Program aimed at rehabilitating children who lost one or both parents in the riots and placing them back in school to finish their education. Children between the ages of 3-18 years are enrolled in Nursery, Primary and Secondary Schools. Many had become orphans and many were traumatized by the brutality of the Gujarat riots after witnessing their parents being burnt alive by mobs,  \r\n\r\nUnder this program, the school fees for 32 children affected by the events of 2002 will be paid. In addition to this, other related expenses such as books, stationery, school bags, uniform, shoes-socks, etc will also be paid for. In addition, there will be continuous monitoring to ensure that the children regularly go to school, also, regular meetings will be conducted with the teachers and principals to assess the progress of the children. In case of problems, necessary action will be taken for counseling of the children. \r\n','The psychological trauma faced by the children requires special care and attention. This program covers the costs of education for the Hamare Bachche children, in addition to:\r\n-Trauma Assessment and Counseling \r\n-School fees and supplies \r\n-Uniforms\r\n-Room and Board (if necessary)\r\n-Health Care Services & Insurance\r\n-Childcare Services for Younger Children \r\n-Vocational Guidance and Trainings \r\n-Extra-curricular Activities and Field Trips \r\n-Organizing special programs like Summer Camps, Workshops, and picnics \r\n-Exam Preparation and Tutoring \r\n\r\nFrom 2002, SEWA has paid school fees and provided uniforms, lunch boxes, schoolbags, textbooks and notebooks as recommended by the school syllabus for each student. Special teams visit the children at school every week. The team meets the class teachers, principals and gets the report of the child’s progress. Regular meetings with parents are held to help counsel parents on how to provide quality education for their children at home. The team members also tutor the weak students and co-ordinate with schoolteachers regularly and especially during the examination time to inspire confidence and increase marks.  ','','','','Provides healthcare, trauma counseling, school fees for the continued education of 32 children affected by communal violence. This allows them to advance to secondary school and acquire skills to succeed in life.  ','The mothers and the family of these children.','This project aims to provide good quality education for the children, to prepare for higher studies and ultimately, to ensure a brighter future. In absence of such facilities, the children might have to discontinue their studies. Through the school, they will also have access to regular health care. The children will also be funded for school picnics, summer camps and participation in various activities like computers, sports etc. for their overall development. In the absence of funds, however, the child would not be able to attend high school. ','','','','','','','','','12 months (June 2008 to May 2009)','','','','','','','','','2009-08-17 15:47:33','2009-09-13 16:25:40',NULL,9,1,1);
INSERT INTO `projects` VALUES (32,3,'2009-08-25 16:43:51','',NULL,'','','2008-07-15 00:00:00','2009-08-21 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'Carolyn\'s Education Project — Dungra Village Childcare Center','High','Fund 1 year of operating cost for childcare center in Dungra Village. The center will provide nutrition, education, and primary health care for 20 children in the surrounding communities',NULL,'','Dharmishtaben, Indiraben',50000,23,0,NULL,NULL,NULL,NULL,'Dungra Village ','Dungarpur District','Rajasthan',2,575,20,NULL,NULL,'','rain fed cultivation and cattle breeding',NULL,NULL,'Village established 150 years ago and being surrounded by hills (dungars) it was named Dungra. Surrounded by forest even today tigers come out near the village. They never worked for agriculture livelihood as the royals took away 3/4 of the produce. Water is available at 70 feet below ground level but is still an issue as the land is stony and rocky and digging well costs about 2 to 3 lacs rupees, not affordable by the villagers. ','','','Dungra village does not have a childcare facility, and as a result children are often left behind on their own while their mothers work in the fields. This project will fund a SEWA-supported childcare center that focuses on the overall development of the children, including both physical and intellectual growth, for 25 village children. Founding a childcare center in Dungra is essential for the health, education, and well-being of its children. The center will provide children with a healthy, encouraging learning environment, nutritious meals, educational field trips, and immunization and primary care. The existence of a full-time childcare center will enable mothers to engage in income-earning activities and start on the path to financial self-reliance.\r\nInvest in this project with Carolyn, and give the children of Dungra a brighter future. Visit http://www.1well.org/dungra/ to learn more.','The condition of the village ponds is such that it leaves the villagers, cattle and cultivation without water leaving them to travel daily in search of water and do casual labor or migrate in search of livelihood. Alternative livelihood training will help the women of the village earn something to survive in days of stress. In absence of a childcare center children have to be left behind on their own while mothers go to fetch water and labor work.\r\n\r\nToday they are in rain fed cultivation and cattle breeding. Deepening and repairing of the wells and village ponds will help them with clean drinking water for both human consumption and cattle. Irrigation facility will be available for nearly 250 Bigha land reducing migration which is as much as 75% at present. Livelihood related trainings and activities would help them earn some income and educate their children especially the girl child. Earning some income will help them survive in their adverse conditions. Childcare center will take care of 20 to 25 children and leave the mothers tension free while at work.  ','','','','','','2 full-time teaching jobs\r\n20 healthier children','','','','','','','','','','','12 months','Available agricultural Land:  1400 Bigha\r\nWith irrigation facilities: 50 BighaWithout irrigation facilities: 1350 Bigha\r\nFutile land: -\r\nType of Soil: stony, sandy, black, hilly\r\nMajor Crops: Corn, rice, banti, kodra, \r\n','Cow: 30\r\nBuffalo: 20\r\nBullock: 100\r\nGoats: 150\r\nSheep: 150\r\nCamel: -\r\n','Ponds: 8 (big & small)\r\nWell: 7 (with water) 13 (dry)\r\nCommunity well: -\r\nBore well: -\r\nHand pump: 6 (working) 1 (not working)\r\nJuth Yojana: Aniket but incomplete so water drains out (needs to be completed) \r\nWater tanks:  - \r\nWater pipe line: -\r\n','Toilets: - \r\nWashing facilities: - \r\n\r\n','Primary Health Care Center: - nurse visits once in a week\r\nMidwife: -\r\nGovernment Clinic: - \r\nDistance to primary health care facility: - Hadmatiya (2½ kms)\r\nDistance to large hospital: Dungarpur (22 kms)\r\n','Distance to public bus stop: daily (one bypassing the village)\r\nCycles: 15\r\nScooter / Motorcycle: 6\r\nTractor: -\r\nJeep: 1\r\nCarts: \r\n','Major businesses: -\r\nGrocery Shop: 4 (small)\r\nPan shop: -\r\nOther businesses/entrepreneurs: -\r\n','Child care center:  - (need 1)\r\nSchool:  up to 5th standard (2½ kms away\r\n','2009-08-17 15:50:32','2009-09-13 16:25:40',NULL,10,1,1);
INSERT INTO `projects` VALUES (33,3,'2009-08-25 18:01:04','',NULL,'','','2008-05-12 00:00:00','2009-08-21 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'Navli Childcare Center','High','Fund 2 years of operating cost for childcare center. The center will provide nutrition, education, and primary health care for 45 children in the surrounding communities',NULL,'Rehana Riyawala / Alka Shah','Kamlaben Natuben',350750,23,6500,'navli_cc_project_budget.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document','31269','2009-08-21 19:47:36','Navli','Anand','Gujarat',2,6500,43,NULL,NULL,'Darbar, Patel, Talpada, Harijan','Agriculture, tobacco factory and miscellaneous workers',NULL,NULL,'','','','Navli is a small village of agricultural laborers and tobacco field workers. As the tobacco industry is the largest employer in Navli, occupational health hazards have prevailed among majority of the villagers and their families. The lack of full-time, quality childcare for the children of these workers has forced many parents to bring their children with them to work in the fields, exposing very young children to these hazards.\r\nThe current childcare center takes care of 40 children between the ages of 0-6 years old, but is in great need of repair and renovation. The center focuses on the overall development of the children, including their physical and intellectual growth. However, the center lacks funds and needs a partner that will help them provide the children with a healthy and encouraging learning environment, nutritious meals, education field trips, immunizations and other primary care. In addition to those direct needs, the center will also help counsel parents on fostering a healthy learning environment at home. Become the Citizen Philanthropist for this project and partner with Navli village to create a positive educational environment for their children. ','At SEWA it is well understood that without childcare, including child development, its goal of full employment and self-reliance will remain unfulfilled. Working mothers cannot take their children to their workplaces without jeopardizing their own work efficiency and their children’s safety. SEWA believes that women’s struggle to emerge out of poverty through the quest for work and income security, must be supported by quality childcare.  SEWA’s childcare programme emerged in mid 1970 from the needs expressed by its members.  \r\n\r\nAlso the rural poor workers in this Village were over exposed to nicotine in the tobacco fields as well as in the factories and thus suffered from various diesease like tubercolouses, Asthama etc.  Same was the case with their children as their does not exist any facility were their children could be taken care and hence, workers had no option but to take their children along with them to factories and they were also exposed to the nicotine environment.  Their education too suffered.\r\n\r\nThus based on the members demand SEWA started the Child Care Centre in the village in the year 1990. Presently 45 children of this poor community members are being taken care at the Centre. ','   1.  Children are provided with nutritious food and are also educated about the same.\r\n   2. Teachers of the childcare center hold regular meetings with the mothers and discuss their children’s development and give their suggestions. During this meetings the mothers are also given training so as that they know what they should do for the development of their children when they are not at the child care centers.\r\n   3. Also the mothers are given trainings on the primary health related aspects so that they could take care of their children and family during such situations\r\n   4. Children are regularly weighed and records of their growth are properly maintained.\r\n   5. The children are provided with nutritious meals and infants are given milk.\r\n   6. The childcare centers are also centers for child immunizations, antenatal and postnatal care. SEWA works closely with the government health programmes for providing these services.\r\n   7. Also if a child is sick and the immediate diagnose is required in such situation the children is referred and taken to the hospital by the child care centres workers.\r\n   8. Children in the centers are involved in pre-primary creative activities like drawing, painting and craftwork.\r\n   9. The celebration of major festival are organised at the child care centers in order that the children get knowledge and awareness for the given festival.\r\n  10. Also the children are taken for the exposure visit which helps in the overall development of the poor children of the members.\r\n\r\n \r\n\r\nThis child care centers play very important role in the life of rural poor workers as this are the centers of their own kind i.e. (a) it serves the children for the whole day that to as per the working hours of the rural poor women members and (b) cater services to the children as small as 15 days. The centers support infants i.e. 0-3 years of age, with milk.  ','The child care centers in the District are managed by co-operatives of childcare providers, which have been formed with SEWA’s support. 45 children starting from the age of 0-6 years are served at each of this centers and focuses on the overall development of the children, including their physical and intellectual growth. Apart from this the other major activities undertaken by the childcare centers run by SEWA are as under.  ','','','    *  This would facilitate the mothers of the above children with increased income as this would allow them to work without any tension for their children. This would also help the families, communities and nation in future as this has been experienced that the children taken education from this centre are good at education and this would help in creating a bright future.\r\n    * This would also lead to more and better education of the elder children, else they are busy taking care of the younger ones','3 full-time teachers\r\n40 children','Families of children','From the operation of  the Childcare Programme following major impacts has been seen.  \r\n\r\n    * It is found that due to the operation of the child care centers the children of the rural poor women are protected from various diseases as they do not have to accompany their mothers at the unhealthy work-place or they are not just roaming around.\r\n    * The child care centers assure the rural poor worker that their children are taken good care and thus they could go for work which amounts to increase in income. Further to this their productivity also increases and they can also do qualitative work\r\n    * Children who have been in SEWA childcare centers value learning and education.\r\n    * The overall development of the children who attends the child care centers is much better compared to others.\r\n    * The meetings with mothers etc. educates the mothers on how to take care of the children when they are at home and also briefs them on the various aspects related to cleanliness and nutrition which further helps the development of their children\r\n    * Also the regular training to the teachers facilitates in the betterment of overall child development and child education\r\n','','2','','','','    *  Permanent jobs created : 3 teachers\r\n    * Productive Time Created: This would facilitate the beneficiaries (parents of 40 children with tension free and more productive working hours ultimately leading hem towards sustainable livelihood\r\n    * Children with childcare/education: 40 children\r\n    * Overall Child development : 40 children\r\n    * More and better education to elder children in family\r\n','','','2 years','Available agricultural Land-763 hectare\r\nWith irrigation facilities: 681 hectares\r\nWithout irrigation facilities:  82 hectares\r\nFutile land: 82 hectares \r\nType of Soil: black and clay \r\n','Cows: 188\r\nBuffalo: 441\r\nBullock: 6\r\nSheep / goat : 11\r\n','Ponds: 10\r\nWell: 6\r\nBore well : 35\r\nJuth Yojana: -\r\nRoof Rain Water Harvesting Tanks: 3\r\nSanitation \r\nToilets:yes in village and not in out skirts\r\nWashing facilities: yes\r\n','Toilets:yes in village and not in out skirts\r\nWashing facilities: yes\r\n','Primary Health Care Centre:yes\r\nGovernment Clinic: 1\r\nPrivate Clinic : 4\r\nDistance to primary health care facility : 1 km.\r\nDistance to large hospital : 5 kms.\r\n','Distance to nearest town : 5 kms.\r\nDistance to public bus stop : 0.5 & 1 km\r\nCycles: 200\r\nScooter : 250\r\nTractor: 30\r\nCarts: 2\r\n','Major businesses: Agriculture and Tobacco Factories\r\nGrocery Shop: 30\r\nOther businesses/entrepreneurs: Poultry \r\n','Government Operated Child care : Yes but operates only from 11 am to 2 pm\r\nSchool: 1 Primary, 1 high school and 1 higher secondary\r\n','2009-08-17 15:50:38','2009-09-13 16:25:40',NULL,6,1,2);
INSERT INTO `projects` VALUES (34,3,'2009-08-17 15:53:13','',NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'CareerBuilder\'s Water & Sanitation Project — Guher Village','High','',NULL,'','',NULL,NULL,0,NULL,NULL,NULL,NULL,'Guher Village','Kutch District','Gujarat',2,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','Guher is an agricultural village in a dry and semi-arid region of Gujarat, India. The village not only lacks basic means of harvesting rainwater for drinking and agriculture, but also lacks basic sanitation facilities. Without sanitation, the village has become nearly unlivable and needs cleaning to prevent a disease outbreak. Members of the village have requested funds to build toilets, build roof rainwater harvesting tanks, conduct a village clean-up, repair their well and build farm ponds. This project will protect the health of Guher residents, make their village a more livable place, and decrease their overall water scarcity.\r\nTo learn more, visit: http://1well.org/guher','','','','','','','Improved sanitation, reduction in disease, increased agricultural output ','','','','','','','','','','','','','','','','','','','','2009-08-17 15:52:10','2009-09-13 16:25:40',NULL,10,1,1);
INSERT INTO `projects` VALUES (35,3,'2009-08-17 15:53:39','',NULL,'','','2008-05-14 00:00:00',NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'','High','',NULL,'','',NULL,NULL,8350,NULL,NULL,NULL,NULL,'Vadgam','Surendranagar','Gujarat',2,5500,NULL,NULL,NULL,'','',NULL,NULL,'','','','Vadgam village is an agricultural and cattle raising community in Gujarat, India. There are no toilets in Vadgam, and the villagers have to walk long distances to go to the toilet. Lack of access to toilets directly affects the lives and livelihoods of the women workers who are forced to answer the call of nature in public view- putting them in a difficult, humiliating, and stressful situation. This lack of basic sanitation dramatically increases the spread of disease throughout the village. Absence of toilets in schools also forces children to leave their classes and walk long distances to relieve themselves, hindering their education. \r\nBecome the Citizen Philanthropist for this project, and partner with Vadgam to provide toilet facilities that will help improve the health, sanitation, and livelihood of the villagers.','','','','','','','Improved health;\r\nincreased work and school hours.','','','','','','','','','','','','','','','','','','','','2009-08-17 15:53:39','2009-09-13 16:25:40',NULL,6,1,2);
INSERT INTO `projects` VALUES (36,3,'2009-08-17 15:55:42','',NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'Neel & Jill\'s Water & Sanitation Project — Della Village','High','',NULL,'','',NULL,NULL,0,NULL,NULL,NULL,NULL,'Della Village','Mehsana District','Gujarat',2,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','This project will support the construction of a system of Roof Rainwater Harvesting Tanks, 2 toilet facilities, and village cleaning tools necessary to improve the health, sanitation, and quality of life of the communities in Della. Roof Rainwater Harvesting will allow families in Della to collect, store, and use the rainwater from the monsoon season during periods of drought. Visit www.1well.org/della to learn more.','','','','','','','Provides 250 families with access to clean, drinking water at their fingertips; time saved from needing to walk to the next village for water collection enables women to engage in income-producing activities; greatly improves the health and sanitation of the entire village.','','','','','','','','','','','','','','','','','','','','2009-08-17 15:55:01','2009-09-13 16:25:40',NULL,10,1,1);
INSERT INTO `projects` VALUES (37,3,'2009-08-17 15:56:54','',NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'Ariadne\'s Solar Lantern Project — Jogad Village','High','',NULL,'','',NULL,NULL,0,NULL,NULL,NULL,NULL,'Jogad Village','Surendranagar District','Gujarat',2,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','Salt workers live in the desert 8 months of the year. Solar lanterns help them ward off wild animals that damage the temporary shelters, and fend off harmful insects. The lanterns also help them during their nightly activities, such as cooking and cleaning. The lanterns charge during the day and provide a sustainable source of light during the night. SEWA has set up a lantern assembly cooperative that sells and repairs the lanterns, creating additional employment opportunities.\r\nVisit http://1well.org/jogad to learn more.','','','','','','','Sustainable source of light for 125 families; increased safety and new sources of livelihood','','','','','','','','','','','','','','','','','','','','2009-08-17 15:56:54','2009-09-13 16:25:40',NULL,10,1,1);
INSERT INTO `projects` VALUES (38,3,'2009-08-17 15:58:36','',NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'Chili Night for Kapurashi Village','High','<a href=\"http://www.1Well.org/kapurashi\" title=\"\"Kapurashi Chili Fest\"\"><img src=\"http://www.1well.org/images/projects/chili_contestants.jpg\" border=\"0\" width=\"195\" height=\"130\" /></a>Kate & John are retired teachers from Lyons Township High School in LaGrange, IL. They have dedicated their lives to teaching English, directing community theater, coaching wrestling, and mentoring students well after graduation. They have remained dedicated to service after their teaching years and were looking for an opportunity to both give in a meaningful way and bring together their old friends and colleagues around a common cause. Through 1Well, they decided to partner with Kapurashi Village and raise $8,500 for water, sanitation, and land development projects through a <a href=\"http://www.1well.org/kapurashi\" title=\"Chili Fest\">Chili Fest</a>.',NULL,'','',NULL,NULL,8,NULL,NULL,NULL,NULL,'Kapurashi','','',NULL,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','2009-08-17 15:58:36','2009-09-13 16:25:40',NULL,10,1,1);
INSERT INTO `projects` VALUES (39,3,'2009-08-17 16:00:10','',NULL,'','',NULL,'2008-05-14 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'','High','',NULL,'','',NULL,NULL,6500,NULL,NULL,NULL,NULL,'Sidhsar','Surendranagar','Gujarat',2,700,NULL,NULL,NULL,'','',NULL,NULL,'','','','Sidhasar farmers earn their livelihoods on small plots ranging from two to five acres of land. Their livelihood relies on the ability to improve the quality of the soil. These farmers need capital to undertake land development activities - filling mud, soil, and sand into the land - that will increase the quality and quantity of crops. Mud filling improves the quality and fertility of the land. Sand filling helps maintain the land’s moisture level while reducing the soil\'s salinity. After such activities, productivity increases 15% to 20%.','','','','','','','Crop productivity increase of 15% to 20%','','','','','','','','','','','','','','','','','','','','2009-08-17 15:59:13','2009-09-13 16:25:41',NULL,6,1,2);
INSERT INTO `projects` VALUES (40,3,'2009-08-17 16:00:43','',NULL,'','',NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,'Eric\'s Water Project — Nokna Village','High','',NULL,'','',NULL,NULL,0,NULL,NULL,NULL,NULL,'Nokna Village','Dungarpur District','Rajasthan',2,NULL,NULL,NULL,NULL,'','',NULL,NULL,'','','','The scarcity of clean drinking water is a significant problem for the semi-arid, farming community of Nokna. Village women must walk up to 2 hours everyday, over very hilly terrain, to collect water 2 to 3 times a day. When they arrive, they have to wait in long lines as the existing hand pump runs out of water and it takes 30 to 60 minutes to recharge. \r\nThis project will support the repair of a hand pump and the construction of a new pump for human drinking water. The hand pumps will allow village women to gain easy access to drinking water, reduce the need to wait for water to recharge, and alleviate the strain put on existing water resources. <br>\r\nTo learn more, visit http://1well.org/eric_nokna_handpumpwell/','','','','','','','Provides 60 families with easy access to clean drinking water; time needed to collect water will be reduced to 30 minutes; improves village health and sanitation.','','','','','','','','','','','','','','','','','','','','2009-08-17 16:00:43','2009-09-13 16:25:41',NULL,10,1,1);
INSERT INTO `projects` VALUES (41,3,'2009-08-17 16:04:50','',NULL,'','',NULL,'2008-06-30 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'','High','',NULL,'','',NULL,NULL,7800,NULL,NULL,NULL,NULL,'Savada','Surendranagar','Gujarat',2,1900,NULL,NULL,NULL,'','',NULL,NULL,'','','','Savada relies on rain-fed agriculture and struggles to maintain the quality of its cultivatable land. In order to improve the quality of the land and to increase both the quality and quantity of their crop production, farmers need to deep plough the land to bringing richer, better soil to the top. This simple exercise, along with sustainable farming techniques, will increase crop yields by 2-3 times. Become the Citizen Philanthropist for this project and help Savada Village access the use of a tractor that will make the deep ploughing of the land possible.','','','','','','','Increasing crop yields by 2-3 times; increase family income.','','','','','','','','','','','','','','','','','','','','2009-08-17 16:04:50','2009-09-13 16:25:41',NULL,6,1,2);
INSERT INTO `projects` VALUES (42,3,'2009-08-25 17:03:35','Recruit CP',NULL,'','','2008-05-12 00:00:00','2009-08-21 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'Napad Vanta Childcare Center','High','Fund 2 years of operating cost for childcare center. The center will provide nutrition, education, and primary health care for 30 children in the surrounding communities',NULL,'Rehana Riyawala / Alkaben Shah',' Sharifaben Aligibhai',219000,23,4600,'napadvanta_cc_project_budget.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document','31429','2009-08-21 20:04:47','Napad Vanta','Anand','Gujarat',2,11300,40,NULL,NULL,'Muslim, Patel, Vaghri, Vankar ','Agriculture laborers and miscellaneous work ',NULL,NULL,'The village is at the distance of 7 kms. from Anand. The village has 12 outskirts. Given the size of the village, it has 2 Panchayat and in one part the majority of the Patel communities resides and in the other area the rest of the community resides. The majority of the village community are agriculture labourers, most of them being tobacco agriculture workers and workers in tobacco factories. Given the employment in the tobacco fields the major issue in this village was the occupational health hazards prevailing among the poor tobacco agriculture workers and their children and lack of child care facilities for the children of these workers.\r\n\r\nPresently SEWA has membership of 1000 in this village. SEWA started organising in this village from the year 1988. Apart from organising the major activities facilitated by SEWA in this village includes tobacco campaign (workers education class, inspection of tobacco factories in co-ordination with the labour department, negotiation with the factory owners and availed the workers with the wages of Rs. 50 / day) health care, child care, micro finance, water campaign (hand pump repairing) and trainings & capacity building of members. ','','','As the tobacco industry is the largest employer in the small village of Napad Vanta, occupational health hazards have prevailed among majority of the villagers and their families. The lack of full-time, quality childcare facilities for the children of these workers, has forced many parents to bring their children with them to work in the fields, exposing very young children to these hazards. \r\n\r\nThe current childcare provides for 35 children between the ages of 0-6 years old, but is in great need of repair and renovation. The center focuses on the overall development of the children, including their physical and intellectual growth. However, the center lacks funds and needs a partner that will help them provide the children with a healthy, encouraging learning environment, nutritious meals, education field trips, and immunization and primary care. In addition to those direct needs, the center will also help counsel parents on fostering a healthy learning environment at home. Become the Citizen Philanthropist for this project and partner with Napad Vanta village to create a positive educational environment for their children.','At SEWA it is well understood that without childcare, including child development, its goal of full employment and self-reliance will remain unfulfilled. Working mothers cannot take their children to their workplaces without jeopardizing their own work efficiency and their children’s safety. SEWA believes that women’s struggle to emerge out of poverty through the quest for work and income security, must be supported by quality childcare.  SEWA’s childcare programme emerged in mid 1970 from the needs expressed by its members.  \r\n\r\nAlso the poor workers in this Village were over exposed to nicotine in the tobacco fields as well as in the factories and thus suffered from various diesease like tubercolouses, Asthama.  Same was the case with their children as their does not exist any facility were their children could be taken care and hence, workers had no option but to take their children along with them to factories and they were also exposed to the nicotine environment.  Their education too suffered.\r\n\r\nThus based on the members demand SEWA started the Child Care Centre in the village in the year 1995. Presently 35 children of these poor community members are being taken care at the Centre. The Child care centre in this village is being operated in the land given by the village gram panchayat. This Centre needs certain repairing and renovation work. ','The child care centers in the District are managed by co-operatives of childcare providers, which have been formed with SEWA’s support. 30 - 35 children starting from the age of 0-6 years are served at each of this centers and focuses on the overall development of the children, including their physical and intellectual growth. Apart from this the other major activities undertaken by the childcare centers run by SEWA are as under.  \r\n\r\n   1. Children are provided with nutritious food and are also educated about the same.\r\n   2. Teachers of the childcare center hold regular meetings with the mothers and discuss their children’s development and give their suggestions. During this meetings the mothers are also given training so as that they know what they should do for the development of their children when they are not at the child care centers.\r\n   3. Also the mothers are given trainings on the primary health related aspects so that they could take care of their children and family during such situations\r\n   4. Children are regularly weighed and records of their growth are properly maintained.\r\n   5. The children are provided with nutritious meals and infants are given milk.\r\n   6. The childcare centers are also centers for child immunizations, antenatal and postnatal care. SEWA works closely with the government health programmes for providing these services.\r\n   7. Also if a child is sick and the immediate diagnose is required in such situation the children is referred and taken to the hospital by the child care centres workers.\r\n   8. Children in the centers are involved in pre-primary creative activities like drawing, painting and craftwork.\r\n   9. The celebration of major festival are organised at the child care centers in order that the children get knowledge and awareness for the given festival.\r\n  10. Also the children are taken for the exposure visit which helps in the overall development of the poor children of the members.\r\n\r\nThis child care centers play very important role in the life of poor workers in the rural areas as this are the centers of their own kind i.e. (a) it serves the children for the whole day that to as per the working hours of the poor rural women members and (b) cater services to the children as small as 15 days. The centers support infants i.e. 0-3 years of age, with milk.  \r\n','The child care centers in the District are managed by co-operatives of childcare providers, which have been formed with SEWA’s support. 30 - 35 children starting from the age of 0-6 years are served at each of this centers and focuses on the overall development of the children, including their physical and intellectual growth. Apart from this the other major activities undertaken by the childcare centers run by SEWA are as under.  ','','','    *  This would facilitate the mothers of the above children with increased income as this would allow them to work without any tension for their children. This would also help the families, communities and nation in future as this has been experienced that the children taken education from this centre are good at education and this would help in creating a bright future.\r\n    * This would also lead to more and better education of the elder children, else they are busy taking care of the younger ones\r\n','3 full-time teachers\r\n35 children','Families of children','From the work experience of three decades in the Childcare Programme following major impacts has been seen.  \r\n\r\n    * It is found that due to the operation of the child care centers the children of the rural poor women are protected from various diseases as they do not have to accompany their mothers at the unhealthy work-place or they are not just roaming around.\r\n    * The child care centers assure the rural poor worker that their children are taken good care and thus they could go for work which amounts to increase in income. Further to this their productivity also increases and they can also do qualitative work\r\n    * Children who have been in SEWA childcare centers value learning and education.\r\n    * The overall development of the children who attends the child care centers is much better compared to others.\r\n    * The meetings with mothers etc. educates the mothers on how to take care of the children when they are at home and also briefs them on the various aspects related to cleanliness and nutrition which further helps the development of their children\r\n    * Also the regular training to the teachers facilitates in the betterment of overall child development and child education\r\n','','2','','','','    *  Permanent jobs created : 3 teachers\r\n    * Productive Time Created: This would facilitate the beneficiaries (parents of 35 - 40 children with tension free and more productive working hours ultimately leading hem towards sustainable livelihood\r\n    * Children with childcare/education: 35-40 children\r\n    * Overall Child development : 35 - 40 children\r\n    * More and better education for elder children in the family\r\n','','','2 years','Available agricultural Land: 759 hectares\r\nWith irrigation facilities: 739 hectares\r\nWithout irrigation facilities:  20 hectares\r\nFutile land: 20 hectares\r\nType of Soil: black and clay\r\n','Cows: 6000\r\nBuffalo: 7000\r\nBullock: 1000\r\nSheep : 5000\r\n','Ponds: 11\r\nWell: 7\r\nBore well : 58\r\nJuth Yojana: -\r\nRoof Rain Water Harvesting Tanks: 5\r\n','Toilets: yes\r\nWashing facilities: yes\r\n','Primary Health Care Centre: 1\r\nGovernment Clinic: 1\r\nDistance to primary health care facility : 1 km\r\nDistance to large hospital : 7 km\r\n','Distance to nearest town : 7 kms.\r\nDistance to public bus stop : 0.5 and 1 km\r\nCycles: 1000\r\nScooter : 175\r\nTractor: 36\r\nCarts: 2\r\n','Major businesses: Tobacco and animal husbandry\r\nGrocery Shop: 25\r\nOther businesses/entrepreneurs: poultry \r\n','Government Operated Child care : Yes but operates only from 11 am to 2 pm but is not as per the working hours of the parents and is just taking care the aspects of education and nutrition is not taken care properly\r\nSchool: 6 primary school, 1 high school \r\n','2009-08-17 16:09:21','2009-09-13 16:25:41',NULL,6,1,1);
INSERT INTO `projects` VALUES (43,3,'2009-08-25 16:55:22','',NULL,'','','2008-05-12 00:00:00','2008-06-30 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'Khadol Childcare Center','High','Fund 2 years of operating cost for childcare center. The center will provide nutrition, education, and primary health care for 30 children in the surrounding communities ',NULL,'Rehana Riyawala / Alka Shah','Vidhyaben',393300,23,7100,'khadol_cc_project_budget.docx','application/vnd.openxmlformats-officedocument.wordprocessingml.document','32574','2009-08-21 20:16:00','Khadol','Anand','Gujarat',2,7205,38,NULL,NULL,'Darbar, Patel, Thakore, Rohit, Talpada, Harijan','Agriculture and Tobacco Workers',NULL,NULL,'The village is at the distance of 7 kms. from Anklav block and 12 kms. from Anand. The majority of the village community are agriculture labourers, majority of them being tobacco agriculture workers. Given the employment in the tobacco fields the major issue in this village was the occupational health hazards prevailing among the poor tobacco agriculture workers and their children and lack of child care facilities for the children of these workers.\r\n\r\nPresently SEWA has membership of 800 in this village. In this village SEWA started organising in the year 1996. Apart from organising the major activities facilitated by SEWA in this village includes health care, child care, micro finance, water campaign (hand pump repairing) and trainings & capacity building of members. ','','','Khadol is a small village of agricultural laborers and tobacco field workers. The tobacco industry is the largest employer in the village and the nature of its cultivation creates health complications for the field workers. One of the most important concerns for these workers remain the lack of full-day childcare facilities, forcing the parents to bring their children to work with them in the field and exposing the young children to the health hazards already faced by their parents.\r\nThe current childcare center takes care of 40 children between the ages of 0-6 years old, but is in great need of repair and renovation. The center focuses on the overall development of the children, including their physical and intellectual growth. However, the center lacks funds and needs a partner that will help them provide the children with full-day childcare, nutritious meals, education field trips, immunizations and other primary care. In addition to those direct needs, the center will also help counsel parents on fostering a healthy learning environment at home. Become the Citizen Philanthropist for this project and partner with Khadol village to create a positive educational environment for their children.','At SEWA it is well understood that without childcare, including child development, its goal of full employment and self-reliance will remain unfulfilled. Working mothers cannot take their children to their workplaces without jeopardizing their own work efficiency and their children’s safety. SEWA believes that women’s struggle to emerge out of poverty through the quest for work and income security, must be supported by quality childcare.  SEWA’s childcare programme emerged in mid 1970 from the needs expressed by its members.  \r\n\r\nAlso the poor workers in this Village were over exposed to nicotine in the tobacco fields and thus suffered from various diesease like tubercolouses, Asthama etc.  Same was the case with their children as their does not exist any facility were their children could be taken care and hence, workers had no option but to take their children along with them to tobacco fields and thus were exposed to the nicotine environment.  Their education too suffered.\r\n\r\nThus based on the members demand SEWA started the Child Care Centre in the village in the year 1994. Presently 40 children of this poor community members are being taken care at the Centre. The Child care centre in this village is been operated in the land given by the village gram panchayat. The Centre needs certain repairing and renovation work. ','   1.  Children are provided with nutritious food and are also educated about the same.\r\n   2. Teachers of the childcare center hold regular meetings with the mothers and discuss their children’s development and give their suggestions. During this meetings the mothers are also given training so as that they know what they should do for the development of their children when they are not at the child care centers.\r\n   3. Also the mothers are given trainings on the primary health related aspects so that they could take care of their children and family during such situations\r\n   4. Children are regularly weighed and records of their growth are properly maintained.\r\n   5. The children are provided with nutritious meals and infants are given milk.\r\n   6. The childcare centers are also centers for child immunizations, antenatal and postnatal care. SEWA works closely with the government health programmes for providing these services.\r\n   7. Also if a child is sick and the immediate diagnose is required in such situation the children is referred and taken to the hospital by the child care centres workers.\r\n   8. Children in the centers are involved in pre-primary creative activities like drawing, painting and craftwork.\r\n   9. The celebration of major festival are organised at the child care centers in order that the children get knowledge and awareness for the given festival.\r\n  10. Also the children are taken for the exposure visit which helps in the overall development of the poor children of the members.\r\n\r\n \r\n\r\nThis child care centers play very important role in the life of rural poor workers as this are the centers of their own kind i.e. (a) it serves the children for the whole day that to as per the working hours of the poor women members and (b) cater services to the children as small as 15 days. The centers support infants i.e. 0-3 years of age, with milk.  ','These center is managed by co-operatives of childcare providers, which have been formed with SEWA’s support. 35-40 children starting from the age of 0-6 years are served at each of this centers and focuses on the overall development of the children, including their physical and intellectual growth. Apart from this the other major activities undertaken by the childcare centers run by SEWA are as under.','','','    *  This would facilitate the mothers of the above children with increased income as this would allow them to work without any tension for their children. This would also help the families, communities and nation in future as this has been experienced that the children taken education from this centre are good at education and this would help in creating a bright future.\r\n    * This would also lead to more and better education of the elder children, else they are busy taking care of the younger ones\r\n','3 full-time teachers \r\n35-40 children \r\n','Families of the children','From the work experience of three decades in the Childcare Programme following major impacts has been seen.  \r\n\r\n    * It is found that due to the operation of the child care centers the children of the rural poor women are protected from various diseases as they do not have to accompany their mothers at the unhealthy work-place or they are not just roaming around.\r\n    * The child care centers assure the rural poor worker that their children are taken good care and thus they could go for work which amounts to increase in income. Further to this their productivity also increases and they can also do qualitative work\r\n    * Children who have been in SEWA childcare centers value learning and education.\r\n    * The overall development of the children who attends the child care centers is much better compared to others.\r\n    * The meetings with mothers etc. educates the mothers on how to take care of the children when they are at home and also briefs them on the various aspects related to cleanliness and nutrition which further helps the development of their children\r\n    * Also the regular training to the teachers facilitates in the betterment of overall child development and child education\r\n','','3','','','','    *  Permanent jobs created : 3 teachers\r\n    * Productive Time Created: This would facilitate the beneficiaries (parents of 35 - 40 children with tension free and more productive working hours ultimately leading hem towards sustainable livelihood\r\n    * Children with childcare/education: 35-40 children\r\n    * Overall Child development : 35 - 40 children\r\n    * More and better education to elder children of the family\r\n','','','2 years','Available agricultural Land: 648 hectare\r\nWith irrigation facilities: 648 hectare \r\nWithout irrigation facilities:  -\r\nFutile land: -\r\nType of Soil: Goralu, Kyari \r\n','Ponds: 8\r\nWell: 46\r\nBore well : 46\r\nJuth Yojana: -\r\nRoof Rain Water Harvesting Tanks: 8\r\n','Ponds: 8\r\nWell: 46\r\nBore well : 46\r\nJuth Yojana: -\r\nRoof Rain Water Harvesting Tanks: 8\r\n\r\n','Toilets: yes in villages and not in outskirts\r\nWashing facilities: yes','Primary Health Care Centre: 2\r\nGovernment Clinic: 1\r\nDistance to primary health care facility : 0.5 kms\r\nDistance to large hospital : 7 kms.\r\n','Distance to nearest town : 7 kms. from Anklav and 12 kms. from Anand\r\nDistance to public bus stop : 0.5 kms\r\nCycles: 500\r\nScooter : 250\r\nTractor: 50\r\nCarts: 4\r\n','Major businesses: Agriculture labourers and animal husbandry\r\nGrocery Shop: 20\r\nOther businesses/entrepreneurs: small shops and carts\r\n','Government Operated Child care : Yes but operates only from 11 am to 2 pm\r\nSchool: 4 till standard 4th; 2 primary and high schools.\r\n','2009-08-17 16:15:02','2009-09-13 16:25:41',NULL,6,1,2);
INSERT INTO `projects` VALUES (44,3,'2009-08-25 16:44:34','',NULL,'','','2008-05-12 00:00:00','2009-08-24 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'Chaklasi Childcare Center','High','Fund 2 years of operating cost for childcare center. The center will provide nutrition, education, and primary health care for 45 children in the surrounding communities ',NULL,'Rehana Riyawala / Alka Shah','Gitaben Jitubhai   ',365000,NULL,NULL,NULL,NULL,NULL,NULL,'Chaklasi','Kheda','Gujarat',2,36101,48,NULL,NULL,'Darbar, Patel, Talpada, Muslim, Harijan','Agriculture workers and vegetable grower',NULL,NULL,'The village is at the distance of 15 kms. from Nadiyad block and 10 kms. from Anand. The village has many out skirts and thus the distance from the outskirts increases. The majority of the village community are agriculture labourers and vegetable growers. The major crops include Wheat, Bajri and vegetables. Given the majority of the poor communities being agriculture workers and lack of child care facilities, they have to take their children along with them in the fields, which hampers their productivity as well as the health and overall development of the children.\r\n\r\nPresently SEWA has membership of 1240 in this village. In this village SEWA started organising in the year 1998. Apart from organising the major activities facilitated by SEWA in this village includes agriculture campaign, health care, child care, micro finance and trainings & capacity building of members.  ','','','','At SEWA it is well understood that without childcare, including child development, its goal of full employment and self-reliance will remain unfulfilled. Working mothers cannot take their children to their workplaces without jeopardizing their own work efficiency and their children’s safety. SEWA believes that women’s struggle to emerge out of poverty through the quest for work and income security, must be supported by quality childcare.  SEWA’s childcare programme emerged in mid 1970 from the needs expressed by its members.  \r\n\r\nAlso given that the poor members of this Village have to work hard in fields in any weather / atmosphere and without any childcare facilities prevalent this poor members have to take their childrens along with them in the unhealthy working environment which not only affect the health and development of the children but also jeopardize their own work efficiency and their children’s safety. Their education too suffered.\r\n\r\nThus based on the members demand SEWA started the Child Care Centre in the village in the year 1997. Presently 45 children of this poor community members are being taken care at the Centre. The Child care centre in this village is been operated in the land given by the village gram panchayat. The Centre needs certain repairing and renovation work. ','These center is managed by co-operatives of childcare providers, which have been formed with SEWA’s support. 45 children starting from the age of 0-6 years are served at each of this centers and focuses on the overall development of the children, including their physical and intellectual growth. Apart from this the other major activities undertaken by the childcare centers run by SEWA are as under.  \r\n\r\n   1. Children are provided with nutritious food and are also educated about the same.\r\n   2. Teachers of the childcare center hold regular meetings with the mothers and discuss their children’s development and give their suggestions. During this meetings the mothers are also given training so as that they know what they should do for the development of their children when they are not at the child care centers.\r\n   3. Also the mothers are given trainings on the primary health related aspects so that they could take care of their children and family during such situations\r\n   4. Children are regularly weighed and records of their growth are properly maintained.\r\n   5. The children are provided with nutritious meals and infants are given milk.\r\n   6. The childcare centers are also centers for child immunizations, antenatal and postnatal care. SEWA works closely with the government health programmes for providing these services.\r\n   7. Also if a child is sick and the immediate diagnose is required in such situation the children is referred and taken to the hospital by the child care centres workers.\r\n   8. Children in the centers are involved in pre-primary creative activities like drawing, painting and craftwork.\r\n   9. The celebration of major festival are organised at the child care centers in order that the children get knowledge and awareness for the given festival.\r\n  10. Also the children are taken for the exposure visit which helps in the overall development of the poor children of the members.\r\n\r\nThis child care centers play very important role in the life of rural poor workers from the informal economy as this are the centers of their own kind i.e. (a) it serves the children for the whole day that to as per the working hours of the poor women members from the informal economy and (b) cater services to the children as small as 15 days. The centers support infants i.e. 0-3 years of age, with milk.  ','These center is managed by co-operatives of childcare providers, which have been formed with SEWA’s support. 45 children starting from the age of 0-6 years are served at each of this centers and focuses on the overall development of the children, including their physical and intellectual growth. Apart from this the other major activities undertaken by the childcare centers run by SEWA are as under.  ','','','    *   This would facilitate the mothers of the above children with increased income as this would allow them to work without any tension for their children. This would also help the families, communities and nation in future as this has been experienced that the children taken education from this centre are good at education and this would help in creating a bright future.\r\n    * This would also lead to more and better education of the elder children, else they are busy taking care of the younger ones\r\n','2 full-time teaching jobs \r\n35 healthier children ','This would help family members generate income by freeing the time that would otherwise be spent on overseeing the children. \r\n\r\nThis would also allow older children to focus on education by freeing time that would otherwise be spent on taking care of their little brothers and sisters ','From the work experience of three decades in the Childcare Programme following major impacts has been seen.  \r\n\r\n    * It is found that due to the operation of the child care centers the children of the rural poor women are protected from various diseases as they do not have to accompany their mothers at the unhealthy work-place or they are not just roaming around.\r\n    * The child care centers assure the rural poor worker that their children are taken good care and thus they could go for work which amounts to increase in income. Further to this their productivity also increases and they can also do qualitative work\r\n    * Children who have been in SEWA childcare centers value learning and education.\r\n    * The overall development of the children who attends the child care centers is much better compared to others.\r\n    * The meetings with mothers etc. educates the mothers on how to take care of the children when they are at home and also briefs them on the various aspects related to cleanliness and nutrition which further helps the development of their children\r\n    * Also the regular training to the teachers facilitates in the betterment of overall child development and child education\r\n','','2','','','','','','','It is program which is running continuously and is presently operational. The operation of this child care centre for 2 years is proposed under the present Program. ','    *  Available agricultural Land: 2260 Hectare\r\n    * With irrigation facilities: 2157\r\n    * Without irrigation facilities: 63 hectares\r\n    * Futile land: 63 Hectare\r\n    * Type of Soil: Black and clay, sandy\r\n','    * Cows: 1000\r\n    * Buffalo: 3500\r\n    * Bullock: 250\r\n    * Sheep : 1500\r\n','    *  Ponds: 35\r\n    * Well: 23\r\n    * Tube well : 25\r\n    * Juth Yojana: -\r\n    * Roof Rain Water Harvesting Tanks: 20\r\n','    *  Toilets:yes\r\n    * Washing facilities: yes\r\n','    *  Primary Health Care Centre: 1\r\n    * Government Clinic: 1\r\n    * Distance to primary health care facility : 1 kms\r\n    * Distance to large hospital : 3 kms and 10 kms\r\n','    *  Distance to nearest town : 10 kms.\r\n    * Distance to public bus stop : 0.5 kms\r\n    * Cycles: 4000\r\n    * Scooter : 3200\r\n    * Tractor: 150\r\n    * Carts: 10\r\n','    *  Major businesses: agriculture workers and animal husbandry\r\n    * Grocery Shop: 400\r\n    * Other businesses/entrepreneurs: Preparation of potato chips\r\n','    *  Government Operated Child care : Yes but operates only from 11 am to 2 pm but is not as per the working hours of the parents and is just taking care the aspects of education and nutrition is not taken care properly\r\n    * School: 27 primary school, 4 high school and 2 Secondary School\r\n','2009-08-25 16:02:34','2009-09-13 16:25:41',NULL,6,1,1);
INSERT INTO `projects` VALUES (45,3,'2009-08-25 16:45:00','',NULL,'','','2008-11-17 00:00:00','2009-08-25 00:00:00',NULL,NULL,'',NULL,NULL,NULL,NULL,'Kahela Childcare Center','High','Fund 1 year of operating cost for childcare center. The center will provide nutrition, education, and primary health care for 20 children in the surrounding communities',NULL,'','',50000,23,NULL,NULL,NULL,NULL,NULL,'Kahela','Sagwada','Gujarat',2,650,20,NULL,NULL,'Adivasi, Damor, Nanoma, Mahida, Manal, Dindo','Rain Fed agriculture, Migrate in search of livelihood – casual labour',NULL,NULL,'Kahela, surrounded by hill tops all around the village and situated in the center was not known a few years before but with the cutting of the forest trees today if we stand on any of the surrounding hill top the village and its small huts / houses scattered on nearly 70 to 80 hill tops could be seen. The villagers’ day ends early, as there is no electricity connection in any of the households.  This is their 8th generation that is residing here but in the name of progress they still lack behind. Getting their basic needs would help them reach out and walk with the world around.  ','','','','','','','','','','','','','','','','','','','','12 months','','    *  Available agricultural Land:  1200 Bigha\r\n    * With irrigation facilities: 50 Bigha\r\n    * Without irrigation facilities: 1150 Bigha\r\n    * Futile land: -\r\n    * Type of Soil: stony, sloppy, red soil\r\n    * Major Crops: Corn, rice, banti-kuri','    *  Cow: 7\r\n    * Buffalo: 6\r\n    * Bullock: 200\r\n    * Goats: 40\r\n    * Sheep: -\r\n    * Camel: -\r\n','    *  Ponds: 1 (big) 1 (small)\r\n    * Well: 10 (with water) 70 (dry)\r\n    * Community well: 2 (not working)\r\n    * Bore well: -\r\n    * Juth Yojana: -\r\n    * River: -\r\n    * Roof Rain Water Harvesting Tanks: -\r\n    * Water tanks:  -\r\n    * Water pipe line: -\r\n','    *  Toilets: -\r\n    * Washing facilities: -\r\n','    *  Primary Health Care Center: Sub center – nurse visits daily\r\n    * Government Clinic: -\r\n    * Distance to primary health care facility: Varda (4 kms) or Tamatiya (8 kms)\r\n    * Distance to large hospital: 21 kms to Sagwada\r\n','    *  Distance to public bus stop: -\r\n    * Cycles: -\r\n    * Scooter / Motorcycle: -\r\n    * Tractor: -\r\n    * Jeep: -\r\n    * Carts: -\r\n','    *  Major businesses: -\r\n    * Grocery Shop: -\r\n    * Pan shop: -\r\n    * Other businesses/entrepreneurs: -\r\n','    *  Child care: 1 (needs for 1 more)\r\n    * School:  up to 8th standard\r\n','2009-08-25 16:41:52','2009-09-13 16:25:41',NULL,6,1,1);
/*!40000 ALTER TABLE `projects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permission_associations`
--

DROP TABLE IF EXISTS `role_permission_associations`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `role_permission_associations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) DEFAULT NULL,
  `permission_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `role_permission_associations`
--

LOCK TABLES `role_permission_associations` WRITE;
/*!40000 ALTER TABLE `role_permission_associations` DISABLE KEYS */;
INSERT INTO `role_permission_associations` VALUES (1,1,1,'2009-08-08 02:38:35','2009-08-08 02:38:35');
INSERT INTO `role_permission_associations` VALUES (2,1,2,'2009-08-08 02:38:35','2009-08-08 02:38:35');
/*!40000 ALTER TABLE `role_permission_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `roles`
--

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'1well_admin','Admin for the whole system. Can pretty much do anything.','2009-08-08 02:38:35','2009-08-08 02:38:35');
INSERT INTO `roles` VALUES (2,'ngo_admin','Admin for one or more NGOs','2009-08-08 02:38:35','2009-08-08 02:38:35');
INSERT INTO `roles` VALUES (3,'cp','Helps manage projects for NGOs','2009-08-08 02:38:35','2009-08-08 02:38:35');
INSERT INTO `roles` VALUES (4,'basic_user','Works on various projects in the system','2009-08-08 02:38:35','2009-08-08 02:38:35');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `schema_migrations`
--

DROP TABLE IF EXISTS `schema_migrations`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `schema_migrations` (
  `version` varchar(255) NOT NULL,
  UNIQUE KEY `unique_schema_migrations` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `schema_migrations`
--

LOCK TABLES `schema_migrations` WRITE;
/*!40000 ALTER TABLE `schema_migrations` DISABLE KEYS */;
INSERT INTO `schema_migrations` VALUES ('20090804043131');
INSERT INTO `schema_migrations` VALUES ('20090804164414');
INSERT INTO `schema_migrations` VALUES ('20090804165153');
INSERT INTO `schema_migrations` VALUES ('20090804175043');
INSERT INTO `schema_migrations` VALUES ('20090804175856');
INSERT INTO `schema_migrations` VALUES ('20090804181740');
INSERT INTO `schema_migrations` VALUES ('20090804182402');
INSERT INTO `schema_migrations` VALUES ('20090804185636');
INSERT INTO `schema_migrations` VALUES ('20090804190650');
INSERT INTO `schema_migrations` VALUES ('20090804201029');
INSERT INTO `schema_migrations` VALUES ('20090804205151');
INSERT INTO `schema_migrations` VALUES ('20090804205746');
INSERT INTO `schema_migrations` VALUES ('20090804205924');
INSERT INTO `schema_migrations` VALUES ('20090804212840');
INSERT INTO `schema_migrations` VALUES ('20090805025352');
INSERT INTO `schema_migrations` VALUES ('20090805030416');
INSERT INTO `schema_migrations` VALUES ('20090805033329');
INSERT INTO `schema_migrations` VALUES ('20090805035621');
INSERT INTO `schema_migrations` VALUES ('20090805035912');
INSERT INTO `schema_migrations` VALUES ('20090805040542');
INSERT INTO `schema_migrations` VALUES ('20090805041319');
INSERT INTO `schema_migrations` VALUES ('20090805041518');
INSERT INTO `schema_migrations` VALUES ('20090805041556');
INSERT INTO `schema_migrations` VALUES ('20090805045529');
INSERT INTO `schema_migrations` VALUES ('20090805045936');
INSERT INTO `schema_migrations` VALUES ('20090806184933');
INSERT INTO `schema_migrations` VALUES ('20090806204203');
INSERT INTO `schema_migrations` VALUES ('20090806204347');
INSERT INTO `schema_migrations` VALUES ('20090807184532');
INSERT INTO `schema_migrations` VALUES ('20090826195124');
INSERT INTO `schema_migrations` VALUES ('20090826195549');
INSERT INTO `schema_migrations` VALUES ('20090826203022');
INSERT INTO `schema_migrations` VALUES ('20090831223730');
INSERT INTO `schema_migrations` VALUES ('20090902020408');
INSERT INTO `schema_migrations` VALUES ('20090902205638');
INSERT INTO `schema_migrations` VALUES ('20090903200806');
INSERT INTO `schema_migrations` VALUES ('20090907220807');
INSERT INTO `schema_migrations` VALUES ('20090908184109');
INSERT INTO `schema_migrations` VALUES ('20090908225034');
INSERT INTO `schema_migrations` VALUES ('20090909185217');
INSERT INTO `schema_migrations` VALUES ('20090909205706');
INSERT INTO `schema_migrations` VALUES ('20090910205638');
INSERT INTO `schema_migrations` VALUES ('20090911191219');
INSERT INTO `schema_migrations` VALUES ('20090912205329');
INSERT INTO `schema_migrations` VALUES ('20090912231249');
INSERT INTO `schema_migrations` VALUES ('20100804182610');
/*!40000 ALTER TABLE `schema_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user_role_associations`
--

DROP TABLE IF EXISTS `user_role_associations`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `user_role_associations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `role_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `user_role_associations`
--

LOCK TABLES `user_role_associations` WRITE;
/*!40000 ALTER TABLE `user_role_associations` DISABLE KEYS */;
INSERT INTO `user_role_associations` VALUES (1,1,1,'2009-08-08 02:38:35','2009-08-08 02:38:35');
INSERT INTO `user_role_associations` VALUES (2,1,4,'2009-08-08 02:38:35','2009-08-08 02:38:35');
INSERT INTO `user_role_associations` VALUES (3,2,4,'2009-08-08 02:41:11','2009-08-08 02:41:11');
INSERT INTO `user_role_associations` VALUES (5,3,4,'2009-08-09 05:28:00','2009-08-09 05:28:00');
INSERT INTO `user_role_associations` VALUES (6,3,1,'2009-08-09 05:29:08','2009-08-09 05:29:08');
INSERT INTO `user_role_associations` VALUES (7,3,3,'2009-08-09 05:30:56','2009-08-09 05:30:56');
INSERT INTO `user_role_associations` VALUES (8,2,2,'2009-08-09 05:54:37','2009-08-09 05:54:37');
INSERT INTO `user_role_associations` VALUES (9,3,2,'2009-08-09 05:55:49','2009-08-09 05:55:49');
INSERT INTO `user_role_associations` VALUES (10,2,1,'2009-08-09 06:15:02','2009-08-09 06:15:02');
INSERT INTO `user_role_associations` VALUES (11,1,3,'2009-08-09 06:16:11','2009-08-09 06:16:11');
INSERT INTO `user_role_associations` VALUES (12,4,4,'2009-08-09 12:02:54','2009-08-09 12:02:54');
INSERT INTO `user_role_associations` VALUES (13,5,4,'2009-08-09 14:30:06','2009-08-09 14:30:06');
INSERT INTO `user_role_associations` VALUES (14,4,1,'2009-08-09 17:16:06','2009-08-09 17:16:06');
INSERT INTO `user_role_associations` VALUES (15,5,1,'2009-08-09 17:16:09','2009-08-09 17:16:09');
INSERT INTO `user_role_associations` VALUES (16,6,4,'2009-08-11 18:25:16','2009-08-11 18:25:16');
INSERT INTO `user_role_associations` VALUES (17,6,3,'2009-08-11 18:32:59','2009-08-11 18:32:59');
INSERT INTO `user_role_associations` VALUES (18,7,4,'2009-08-11 18:40:47','2009-08-11 18:40:47');
INSERT INTO `user_role_associations` VALUES (19,8,4,'2009-08-11 18:40:54','2009-08-11 18:40:54');
INSERT INTO `user_role_associations` VALUES (20,6,1,'2009-08-11 19:00:01','2009-08-11 19:00:01');
INSERT INTO `user_role_associations` VALUES (21,7,1,'2009-08-11 19:00:11','2009-08-11 19:00:11');
INSERT INTO `user_role_associations` VALUES (22,8,1,'2009-08-11 19:00:20','2009-08-11 19:00:20');
INSERT INTO `user_role_associations` VALUES (23,9,4,'2009-08-17 14:11:34','2009-08-17 14:11:34');
INSERT INTO `user_role_associations` VALUES (24,6,3,'2009-08-18 16:39:50','2009-08-18 16:39:50');
INSERT INTO `user_role_associations` VALUES (26,10,4,'2009-08-20 03:17:48','2009-08-20 03:17:48');
INSERT INTO `user_role_associations` VALUES (27,10,2,'2009-08-20 03:19:31','2009-08-20 03:19:31');
INSERT INTO `user_role_associations` VALUES (28,9,1,'2009-08-21 15:30:16','2009-08-21 15:30:16');
INSERT INTO `user_role_associations` VALUES (29,11,4,'2009-08-21 15:37:25','2009-08-21 15:37:25');
/*!40000 ALTER TABLE `user_role_associations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `login` varchar(40) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `crypted_password` varchar(40) DEFAULT NULL,
  `salt` varchar(40) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `remember_token` varchar(40) DEFAULT NULL,
  `remember_token_expires_at` datetime DEFAULT NULL,
  `activation_code` varchar(40) DEFAULT NULL,
  `activated_at` datetime DEFAULT NULL,
  `state` varchar(255) DEFAULT 'passive',
  `details_type` varchar(255) DEFAULT NULL,
  `details_id` int(11) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `zip` varchar(255) DEFAULT NULL,
  `state_code` varchar(255) DEFAULT NULL,
  `phone_number` varchar(255) DEFAULT NULL,
  `skype_username` varchar(255) DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  `twitter_access_key` varchar(50) DEFAULT NULL,
  `twitter_secret_key` varchar(50) DEFAULT NULL,
  `facebook_auth_token` varchar(100) DEFAULT NULL,
  `facebook_session_key` varchar(100) DEFAULT NULL,
  `facebook_uid` varchar(100) DEFAULT NULL,
  `city_name` varchar(255) DEFAULT NULL,
  `state_name` varchar(255) DEFAULT NULL,
  `lat` float DEFAULT NULL,
  `lng` float DEFAULT NULL,
  `address1` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `index_users_on_login` (`login`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'onewell_admin','admin@1well.example.com','e3eed24047525765bd02eb31b54f92e2a2b0c0aa','048d6d243b49a9c3a17218afbe9c0219563b6006','2009-08-08 02:38:35','2009-08-08 02:38:35',NULL,NULL,NULL,'2009-08-08 02:38:35','active',NULL,NULL,'1Well','Admin','12345',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `users` VALUES (2,'basic_user','matt@expectedbehavior.com','8b5e8b99b6715055e22260946e68dbcb16f4bc57','7daaa5f5c2f998f1ede7fcdc0a890452bc7b46a7','2009-08-08 02:41:11','2009-08-08 02:41:37',NULL,NULL,NULL,'2009-08-08 02:41:37','active',NULL,NULL,'Bob','Dole','12345',NULL,'','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `users` VALUES (3,'moorage','matt@thrivesmart.com','d8e2e89b661954797f0c30ba80c5a7a5900d74eb','f4fa2830c22395c5981062afffada9ba9304a88c','2009-08-09 05:28:00','2009-08-09 05:28:39',NULL,NULL,NULL,'2009-08-09 05:28:39','active',NULL,NULL,'Matthew','Moore','94105',NULL,'650 888-5962','moorage',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `users` VALUES (4,NULL,'mjslaby@gmail.com','7c899e622c4bc37338cbacdd05e0ec5da2943c86','ea3a956f40ad7f54e2f313cee04a1adc754b25ac','2009-08-09 12:02:54','2009-08-09 12:03:03',NULL,NULL,NULL,'2009-08-09 12:03:03','active',NULL,NULL,'Michael','Slaby','60611',NULL,'','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `users` VALUES (5,NULL,'dan.morrison@1well.org','18c3ba2f68aa45112a793864ce0a4b3e45e25b0e','8f36d609047310bc80cf2a0e2c99e77ada41f6b0','2009-08-09 14:30:06','2009-08-09 14:30:45',NULL,NULL,NULL,'2009-08-09 14:30:45','active',NULL,NULL,'Dan','Morrison','20002',NULL,'202.431.1834','dmorrison99',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `users` VALUES (6,NULL,'may.yu@1well.org','2ed8c090b4d0aa345107ade9b50d28b0b74e0d32','8d96cf4db6e72954ae26e2672f43af6ebb1eed54','2009-08-11 18:25:16','2009-08-11 18:34:33',NULL,NULL,NULL,'2009-08-11 18:34:33','active',NULL,NULL,'May','Yu','20010',NULL,'6268419632','di.may.yu',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `users` VALUES (7,NULL,'jen.1well@gmail.com','150d3f7017fe2c3250c08ddf666b6ae2feeb1253','304b18fc7ef9c8583a25c0d3d5979ad9efe22581','2009-08-11 18:40:47','2009-08-11 18:47:13',NULL,NULL,NULL,'2009-08-11 18:47:13','active',NULL,NULL,'Jenny','van der Heyde','20009',NULL,'9518182660','gelukkig22',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `users` VALUES (8,NULL,'irene.1well@gmail.com','39e82e092c49e3634489e695b7beaab5f263329e','7c95dbd7c6e3cdfe3bd2ce1b71fb4a9d2543227a','2009-08-11 18:40:54','2009-08-11 18:47:08',NULL,NULL,NULL,'2009-08-11 18:47:08','active',NULL,NULL,'Irene ','Moskowitz','11561',NULL,'','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `users` VALUES (9,NULL,'minh.1well@gmail.com','ccf2de84db733253b054161823bc6de28e90325b','af8f00dc1b371b628c72df47b0557e91610c353d','2009-08-17 14:11:34','2009-08-21 15:38:06',NULL,NULL,NULL,'2009-08-21 15:38:06','active',NULL,NULL,'Minh','Phan','94305',NULL,'','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `users` VALUES (10,NULL,'aebbinghaus@coprodeliusa.org','0c870231f5ffaa4e3346bf1ff208d424869cfcd0','4db91f6555efc789026c62c0565eecbaba09036b','2009-08-20 03:17:48','2009-08-20 18:20:01',NULL,NULL,NULL,'2009-08-20 18:20:01','active',NULL,NULL,'Alycia','Ebbinghaus','20008',NULL,'860.608.6380','alycia.ebbinghaus',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `users` VALUES (11,NULL,'mqphan@stanford.edu','db4fd6c680dfe5653c5f0697e4ca658165991e5f','b6a1529422ccefc8caaa7ad12c929388bf325d95','2009-08-21 15:37:25','2009-08-21 15:37:25',NULL,NULL,'2fadaa85d6ccb4882382c5f1c938a2823627f591',NULL,'pending',NULL,NULL,'Minh','Phan','20009',NULL,'2026401845','',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `watched_projects`
--

DROP TABLE IF EXISTS `watched_projects`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `watched_projects` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `project_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `watched_projects`
--

LOCK TABLES `watched_projects` WRITE;
/*!40000 ALTER TABLE `watched_projects` DISABLE KEYS */;
/*!40000 ALTER TABLE `watched_projects` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2009-09-13 16:57:05
